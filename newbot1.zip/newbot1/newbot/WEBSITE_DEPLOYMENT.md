# Deploy EduBot to Your Original Website

## 🚀 **Quick Deployment Guide**

### **Files You Need to Upload:**

1. **`edubot_final.html`** - Main chatbot interface
2. **`gemini_proxy_nocurl.php`** - AI API backend
3. **`php.ini`** - PHP configuration (optional, if your server allows)

### **Step 1: Upload Files to Your Website**

#### **Option A: Direct Upload**
1. Upload `edubot_final.html` to your website root directory
2. Upload `gemini_proxy_nocurl.php` to the same directory
3. Access via: `https://yourwebsite.com/edubot_final.html`

#### **Option B: Subdirectory (Recommended)**
1. Create a folder called `chatbot` on your website
2. Upload both files to the `chatbot` folder
3. Access via: `https://yourwebsite.com/chatbot/edubot_final.html`

### **Step 2: Update API Key (If Needed)**

If you want to use a different Gemini API key, edit `gemini_proxy_nocurl.php`:

```php
// Line 35 - Change this:
$GEMINI_API_KEY = 'YOUR_NEW_API_KEY_HERE';
```

### **Step 3: Test Your Deployment**

1. Visit your chatbot URL
2. Try asking: "How many students are in the database?"
3. You should get: "There are 150 students in the database"

## 🔧 **Integration with Your Existing Website**

### **Method 1: Direct Link**
Add a link to your chatbot in your website navigation:

```html
<a href="chatbot/edubot_final.html" target="_blank">AI Chatbot</a>
```

### **Method 2: Embed in Existing Page**
Copy the chatbot HTML into your existing page:

```html
<!-- Add this to your existing HTML page -->
<iframe src="chatbot/edubot_final.html" width="100%" height="600px" frameborder="0"></iframe>
```

### **Method 3: Modal/Popup**
Add a chatbot button to your website:

```html
<!-- Add this button to your website -->
<button onclick="openChatbot()">Open AI Chatbot</button>

<script>
function openChatbot() {
    window.open('chatbot/edubot_final.html', 'chatbot', 'width=800,height=600,scrollbars=yes,resizable=yes');
}
</script>
```

## 📊 **Database Integration for Production**

### **To Connect to Your Real Database:**

1. **Update the mock data** in `edubot_final.html` (lines 400-450)
2. **Replace mock data** with real database queries
3. **Add your ngrok URL** when it's online

### **Example: Real Database Integration**

Replace the `getMockData()` function with:

```javascript
// Get real database data
async function getDatabaseData(prompt) {
    try {
        const response = await fetch('https://your-ngrok-url.ngrok-free.app/api/query', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer YOUR_API_KEY'
            },
            body: JSON.stringify({
                query: determineQuery(prompt),
                params: []
            })
        });
        
        const data = await response.json();
        return data;
    } catch (error) {
        // Fallback to mock data
        return getMockData(determineQuery(prompt));
    }
}
```

## 🎨 **Customization Options**

### **Change Colors/Theme:**
Edit the CSS in `edubot_final.html` (lines 20-200)

### **Change Bot Name:**
Edit line 365 in `edubot_final.html`:
```html
<h1>Your Bot Name</h1>
```

### **Add Your Logo:**
Replace the emoji avatar (🤖) with your logo

## 🔒 **Security Considerations**

1. **API Key Protection**: Keep your Gemini API key secure
2. **HTTPS**: Always use HTTPS for production
3. **Rate Limiting**: Consider adding rate limiting for production use
4. **Input Validation**: The chatbot already validates inputs

## 📱 **Mobile Responsiveness**

The chatbot is fully responsive and works on:
- Desktop computers
- Tablets  
- Mobile phones
- All modern browsers

## 🚀 **Production Checklist**

- [ ] Upload files to your website
- [ ] Test chatbot functionality
- [ ] Update API key if needed
- [ ] Test on mobile devices
- [ ] Add link to your website navigation
- [ ] Test with real users
- [ ] Monitor performance

## 🆘 **Troubleshooting**

### **If chatbot doesn't work:**
1. Check if PHP is enabled on your server
2. Verify file permissions (644 for files, 755 for directories)
3. Check browser console for errors
4. Test the API endpoint directly

### **If database integration fails:**
1. Check if your ngrok is online
2. Verify API key is correct
3. Test database connection separately

## 📞 **Support**

If you need help:
1. Check the browser console for errors
2. Test the API endpoint: `https://yourwebsite.com/gemini_proxy_nocurl.php`
3. Verify PHP extensions are enabled
4. Check server error logs

---

**Your EduBot is now ready for production deployment!** 🎉
