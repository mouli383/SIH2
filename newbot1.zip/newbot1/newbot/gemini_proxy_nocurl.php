<?php
// Gemini Proxy WITHOUT cURL dependency - Complete Working Version
error_reporting(0);
ini_set('display_errors', 0);

// Check if required extensions are available
$required_extensions = ['openssl', 'curl'];
$missing_extensions = [];

foreach ($required_extensions as $ext) {
    if (!extension_loaded($ext)) {
        $missing_extensions[] = $ext;
    }
}

// If both cURL and OpenSSL are missing, we can't make HTTPS requests
if (count($missing_extensions) >= 2) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    echo json_encode([
        'success' => false,
        'error' => 'Missing required PHP extensions: ' . implode(', ', $missing_extensions) . '. Please enable OpenSSL or cURL extension in your PHP configuration to use HTTPS APIs.',
        'solution' => 'Contact your hosting provider to enable OpenSSL extension, or install cURL extension.',
        'extensions_available' => get_loaded_extensions()
    ]);
    exit;
}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Your Gemini API Key
$GEMINI_API_KEY = 'AIzaSyC4fhFQ_Nesb1liH4dsCmL81TsrvBtF1ZU';
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

// Get request method safely
$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';

// Handle OPTIONS (CORS preflight)
if ($method === 'OPTIONS') {
    exit(0);
}

// Handle GET (testing)
if ($method === 'GET') {
    echo json_encode([
        'status' => 'success',
        'message' => 'EduBot Proxy is working perfectly!',
        'curl_available' => function_exists('curl_init') ? 'Yes' : 'No',
        'file_get_contents' => function_exists('file_get_contents') ? 'Yes' : 'No',
        'method' => 'file_get_contents (no cURL needed)',
        'timestamp' => date('Y-m-d H:i:s'),
        'ready' => true
    ]);
    exit;
}

// Handle POST (actual chat)
if ($method !== 'POST') {
    echo json_encode([
        'success' => false, 
        'error' => 'Only POST requests allowed for chat'
    ]);
    exit;
}

try {
    // Get input data
    $input = file_get_contents('php://input');
    if (!$input) {
        throw new Exception('No input data received');
    }
    
    $data = json_decode($input, true);
    if (!$data || !isset($data['prompt'])) {
        throw new Exception('Invalid input format - expected JSON with prompt field');
    }
    
    $prompt = trim($data['prompt']);
    if (empty($prompt)) {
        throw new Exception('Empty prompt provided');
    }
    
    // Prepare request data for Gemini API
    $requestData = [
        'contents' => [
            [
                'parts' => [
                    ['text' => $prompt]
                ]
            ]
        ],
        'generationConfig' => [
            'temperature' => 0.7,
            'topK' => 40,
            'topP' => 0.95,
            'maxOutputTokens' => 1024
        ],
        'safetySettings' => [
            ['category' => 'HARM_CATEGORY_HARASSMENT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
            ['category' => 'HARM_CATEGORY_HATE_SPEECH', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
            ['category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE'],
            ['category' => 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold' => 'BLOCK_MEDIUM_AND_ABOVE']
        ]
    ];
    
    // Create context for file_get_contents
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => [
                'Content-Type: application/json',
                'User-Agent: EduBot/1.0',
                'Accept: application/json'
            ],
            'content' => json_encode($requestData),
            'timeout' => 30,
            'ignore_errors' => true,
            'follow_location' => true,
            'max_redirects' => 3
        ],
        'ssl' => [
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
            'crypto_method' => STREAM_CRYPTO_METHOD_TLS_CLIENT
        ]
    ]);
    
    // Make request to Gemini API
    $url = $GEMINI_API_URL . '?key=' . $GEMINI_API_KEY;
    
    // Enable error reporting to capture more details
    $old_error_reporting = error_reporting(E_ALL);
    $old_display_errors = ini_set('display_errors', 1);
    
    $response = @file_get_contents($url, false, $context);
    
    // Restore error reporting
    error_reporting($old_error_reporting);
    ini_set('display_errors', $old_display_errors);
    
    if ($response === false) {
        $error = error_get_last();
        $errorMsg = 'Failed to connect to Gemini API';
        if ($error && isset($error['message'])) {
            $errorMsg .= ' - ' . $error['message'];
        }
        $errorMsg .= ' - Check internet connection and API key';
        throw new Exception($errorMsg);
    }
    
    // Get HTTP response code
    $http_response_header = $http_response_header ?? [];
    $status_line = isset($http_response_header[0]) ? $http_response_header[0] : '';
    $http_code = 200; // Default to success
    
    if (preg_match('/HTTP\/\d\.\d\s+(\d+)/', $status_line, $matches)) {
        $http_code = intval($matches[1]);
    }
    
    if ($http_code !== 200) {
        throw new Exception('API returned HTTP ' . $http_code . ' - ' . substr($response, 0, 200));
    }
    
    // Parse JSON response
    $result = json_decode($response, true);
    if (!$result) {
        throw new Exception('Invalid JSON response from Gemini API');
    }
    
    // Check for API errors
    if (isset($result['error'])) {
        $errorMsg = isset($result['error']['message']) ? $result['error']['message'] : 'Unknown API error';
        throw new Exception('Gemini API error: ' . $errorMsg);
    }
    
    // Extract response text
    if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
        $responseText = $result['candidates'][0]['content']['parts'][0]['text'];
        
        // Return successful response
        echo json_encode([
            'success' => true,
            'response' => $responseText
        ]);
        
    } else {
        throw new Exception('No response text found in API result');
    }
    
} catch (Exception $e) {
    // Return error response
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

// Ensure clean exit
exit;
?>