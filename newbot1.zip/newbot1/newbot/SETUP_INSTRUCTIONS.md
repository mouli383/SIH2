# EduBot Setup Instructions

## Issue Identified
Your PHP installation is missing the required extensions for HTTPS connections. The Gemini API requires HTTPS, but your current PHP setup doesn't have OpenSSL or cURL extensions enabled.

## Solutions

### Option 1: Enable Required PHP Extensions (Recommended)

#### For XAMPP/WAMP/MAMP:
1. Open your PHP configuration file (`php.ini`)
2. Find these lines and uncomment them (remove the semicolon):
   ```ini
   extension=openssl
   extension=curl
   ```
3. Restart your web server

#### For Windows with PHP installed separately:
1. Download the appropriate PHP version with OpenSSL and cURL support
2. Or enable extensions in your `php.ini` file as shown above

#### For Linux/Ubuntu:
```bash
sudo apt-get install php-openssl php-curl
sudo systemctl restart apache2  # or nginx
```

### Option 2: Use a Different PHP Installation
Install a PHP version that includes OpenSSL and cURL extensions by default.

### Option 3: Use a Hosting Service
Deploy your chatbot to a hosting service that has the required extensions enabled.

## Testing Your Setup

After enabling the extensions, test with:
```bash
php -r "echo 'OpenSSL: ' . (extension_loaded('openssl') ? 'Enabled' : 'Disabled') . PHP_EOL; echo 'cURL: ' . (extension_loaded('curl') ? 'Enabled' : 'Disabled') . PHP_EOL;"
```

Both should show "Enabled".

## Current Status
- ✅ Frontend (HTML) is working correctly
- ✅ Backend (PHP) logic is correct
- ❌ Missing PHP extensions for HTTPS connections
- ✅ API key format is correct
- ✅ Error handling is implemented

## Next Steps
1. Enable the required PHP extensions
2. Test the API connection
3. Your chatbot will be fully functional!

## Files in This Project
- `edubot_complete.html` - Chatbot interface
- `gemini_proxy_nocurl.php` - API integration (requires OpenSSL/cURL)
- `SETUP_INSTRUCTIONS.md` - This file


