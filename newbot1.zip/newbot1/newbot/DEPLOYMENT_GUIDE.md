# EduBot Database Integration - Deployment Guide

## 🚀 Quick Deployment for Your Existing Website

### Files to Upload to Your Website

1. **Core Files:**
   - `edubot_with_database.html` - Main chatbot interface
   - `gemini_proxy_with_database.php` - AI integration with database
   - `database_integration.php` - Database connection layer
   - `php.ini` - PHP configuration (if needed)

2. **Optional Files:**
   - `edubot_complete.html` - Original version without database
   - `test_proxy.php` - For testing without database

### 🔧 Integration Steps

#### Step 1: Upload Files
Upload all files to your website's root directory or a subdirectory like `/chatbot/`

#### Step 2: Update Database Credentials
Edit `database_integration.php` and update these values:
```php
// Line 35-36
$dbIntegration = new DatabaseIntegration(
    'EduSafeAI_SecretKey_9@7$4!1q',  // Your API key
    'https://ece5159d9e28.ngrok-free.app'  // Your ngrok URL
);
```

#### Step 3: Update API Key (if needed)
Edit `gemini_proxy_with_database.php` and update:
```php
// Line 15
$GEMINI_API_KEY = 'AIzaSyC4fhFQ_Nesb1liH4dsCmL81TsrvBtF1ZU';
```

#### Step 4: Test the Integration
1. Visit: `https://yourwebsite.com/edubot_with_database.html`
2. Try asking: "Show me overall student statistics"
3. Check if database data is returned

### 🎯 How It Works

#### Database Integration Flow:
1. **User asks a question** → Frontend sends to `gemini_proxy_with_database.php`
2. **AI analyzes the question** → Determines if database query is needed
3. **Database query** → If needed, queries your ngrok API
4. **Enhanced response** → AI responds with real data context

#### Supported Query Types:
- **Student Statistics**: "Show me overall student statistics"
- **Dropout Risk**: "Which students are at risk of dropping out?"
- **Attendance Data**: "What is the average attendance rate?"
- **Individual Students**: "Find student with ID 12345"
- **Academic Performance**: "Show me grade distribution"
- **Search**: "Find students named John"

### 🔌 API Endpoints Your Backend Should Support

Your ngrok API should handle these endpoints:

#### 1. General Query Endpoint
```
POST /api/query
Content-Type: application/json
Authorization: Bearer EduSafeAI_SecretKey_9@7$4!1q

{
    "api_key": "EduSafeAI_SecretKey_9@7$4!1q",
    "query": "SELECT * FROM students",
    "params": [],
    "timestamp": 1234567890
}
```

#### 2. Expected Response Format
```json
{
    "success": true,
    "data": [
        {
            "student_id": "12345",
            "name": "John Doe",
            "grade": "10",
            "attendance_rate": 85.5
        }
    ]
}
```

### 📊 Database Schema Recommendations

Your database should have these tables:

#### Students Table
```sql
CREATE TABLE students (
    student_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100),
    grade VARCHAR(10),
    attendance_rate DECIMAL(5,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Academic Performance Table
```sql
CREATE TABLE academic_performance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50),
    subject VARCHAR(50),
    grade DECIMAL(5,2),
    semester VARCHAR(20),
    FOREIGN KEY (student_id) REFERENCES students(student_id)
);
```

#### Attendance Table
```sql
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50),
    date DATE,
    status ENUM('present', 'absent', 'late'),
    FOREIGN KEY (student_id) REFERENCES students(student_id)
);
```

### 🛠️ Customization Options

#### 1. Modify Database Queries
Edit `database_integration.php` to match your actual database schema.

#### 2. Add New Query Types
Add new methods to the `DatabaseIntegration` class for specific queries.

#### 3. Customize AI Prompts
Edit the prompt templates in `gemini_proxy_with_database.php`.

#### 4. Styling
Modify the CSS in `edubot_with_database.html` to match your website's design.

### 🔒 Security Considerations

1. **API Key Protection**: Keep your API keys secure
2. **Input Validation**: The system validates all inputs
3. **SQL Injection**: Uses parameterized queries
4. **Rate Limiting**: Consider adding rate limiting for production

### 🐛 Troubleshooting

#### Common Issues:

1. **Database Connection Failed**
   - Check ngrok URL is accessible
   - Verify API key is correct
   - Check CORS settings

2. **No Data Returned**
   - Verify database has data
   - Check query syntax
   - Test API endpoints directly

3. **AI Not Using Database Data**
   - Check if keywords match database query triggers
   - Verify database response format
   - Check error logs

### 📱 Mobile Responsiveness

The chatbot is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile phones
- All modern browsers

### 🎨 Integration with Your Website

#### Option 1: Standalone Page
- Direct link to `edubot_with_database.html`
- Perfect for dedicated chatbot page

#### Option 2: Embedded in Existing Page
- Copy the HTML structure into your existing page
- Include the CSS and JavaScript
- Update file paths as needed

#### Option 3: Modal/Popup
- Convert to modal dialog
- Add trigger button to your website
- Include overlay and close functionality

### 📈 Analytics and Monitoring

Consider adding:
- User interaction tracking
- Query success/failure rates
- Popular question analysis
- Performance monitoring

### 🚀 Production Deployment Checklist

- [ ] Upload all files to web server
- [ ] Update API keys and URLs
- [ ] Test database connectivity
- [ ] Verify AI responses include real data
- [ ] Test on mobile devices
- [ ] Check error handling
- [ ] Monitor performance
- [ ] Set up logging
- [ ] Configure backups

### 📞 Support

If you encounter issues:
1. Check browser console for errors
2. Verify PHP error logs
3. Test API endpoints directly
4. Check database connectivity
5. Verify file permissions

Your EduBot is now ready to provide intelligent, data-driven insights about your students! 🎓


