<?php
require_once 'config.php';
include "lang_config.php";
// session_start();

if($_SERVER['REQUEST_METHOD']==='POST'){
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $st = $pdo->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?, 'mentor')");
    try {
        $st->execute([$name, $email, $pass]);
        $msg = $lang['mentor_created'];
    } catch(Exception $e){
        $err = $lang['email_exists'];
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title><?=$lang['create_mentor']?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="center">
<div class="card">
  <h2><?=$lang['create_mentor']?></h2>
  
  <?php if(!empty($msg)) echo "<p class='success'>".htmlspecialchars($msg)."</p>"; ?>
  <?php if(!empty($err)) echo "<p class='err'>".htmlspecialchars($err)."</p>"; ?>

  <form method="post">
    <input name="name" placeholder="<?=$lang['name']?>" required>
    <input name="email" type="email" placeholder="<?=$lang['email']?>" required>
    <input name="password" type="password" placeholder="<?=$lang['password']?>" required>
    <button><?=$lang['register']?></button>
    
  </form>

  <p>
    <a href="index.php"><?=$lang['back_home']?></a>
     <!-- <button class="btn btn-parent" onclick="location.href='mentor_login.php'"><?=$lang['mentor_login']?></button> -->
  </p>
</div>
</body>
</html>