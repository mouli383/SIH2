<!-- 


<?php

require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $n = trim($_POST['name']);
    $e = trim($_POST['email']);
    $p = $_POST['password'];

    if($n && $e && $p) {
        $h = password_hash($p, PASSWORD_DEFAULT);
        $st = $pdo->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)");

        try {
            $st->execute([$n, $e, $h, 'parent']); 
            header('Location: parent_login.php'); 
            exit;
        } catch (Exception $ex) {
            $err = $ex->getMessage();
        }
    } else {
        $err = "Fill all fields.";
    }
}
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Create Parent</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="center">
<div class="card">
    <h2>Create Parent</h2>
    <?php if(!empty($err)) echo "<p class='err'>".htmlspecialchars($err)."</p>"; ?>
    <form method="post">
        <input name="name" placeholder="Full name" required>
        <input name="email" type="email" placeholder="Email" required>
        <input name="password" type="password" placeholder="Password" required>
        <button>Create</button>
    </form>
</div>
</body>
</html> -->


<?php
require_once 'config.php';
require_once 'helpers.php';
session_start(); // ensure session

// === Language handling ===
$lang_code = $_SESSION['lang'] ?? 'en';
$lang_file = "lang/{$lang_code}.php";
if(file_exists($lang_file)){
    include $lang_file;
} else {
    $lang = [
        "create_parent" => "Create Parent",
        "full_name" => "Full Name",
        "email" => "Email",
        "password" => "Password",
        "create_btn" => "Create",
        "fill_required" => "Fill all required fields."
    ];
}

// === Handle form submission ===
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $n = trim($_POST['name']);
    $e = trim($_POST['email']);
    $p = $_POST['password'];

    if($n && $e && $p) {
        $h = password_hash($p, PASSWORD_DEFAULT);
        $st = $pdo->prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?,?,?,?)");

        try {
            $st->execute([$n, $e, $h, 'parent']); 
            header('Location: parent_login.php'); 
            exit;
        } catch (Exception $ex) {
            $err = $ex->getMessage();
        }
    } else {
        $err = $lang['fill_required'] ?? 'Fill all required fields.';
    }
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($lang['create_parent'] ?? 'Create Parent') ?></title>
<link rel="stylesheet" href="assets/style.css">
<style>
:root{
  --bg:#0b1020; --card:#0f1724; --txt:#eaf2f8; --link:#60a5fa; --err:#ef4444;
}
*{box-sizing:border-box;}
body{margin:0;font-family:Inter,system-ui,Segoe UI,Roboto,Arial;background:var(--bg);color:var(--txt);}
.center{display:grid;place-items:center;min-height:100vh;padding:20px;}
.card{background:var(--card);padding:24px;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.5);width:min(520px,96vw);text-align:center;}
.card h2{margin-bottom:25px;}
input,button{width:100%;padding:10px 12px;margin:.5rem 0;border-radius:10px;border:1px solid #223148;background:#0d1524;color:var(--txt);}
button{cursor:pointer;background:#2563eb;border:0;}
.err{color:var(--err);margin-bottom:10px;}
</style>
</head>
<body>
<div class="center">
<div class="card">
<h2><?= htmlspecialchars($lang['create_parent'] ?? 'Create Parent') ?></h2>
<?php if(!empty($err)) echo "<p class='err'>".htmlspecialchars($err)."</p>"; ?>
<form method="post">
    <input name="name" placeholder="<?= htmlspecialchars($lang['full_name'] ?? 'Full Name') ?>" required>
    <input name="email" type="email" placeholder="<?= htmlspecialchars($lang['email'] ?? 'Email') ?>" required>
    <input name="password" type="password" placeholder="<?= htmlspecialchars($lang['password'] ?? 'Password') ?>" required>
    <button><?= htmlspecialchars($lang['create_btn'] ?? 'Create') ?></button>
</form>
</div>
</div>
</body>
</html>
