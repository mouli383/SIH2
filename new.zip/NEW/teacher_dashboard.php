<!-- <?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('teacher');
$counts = risk_counts($pdo);
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Teacher Dashboard</title>
<link rel="stylesheet" href="assets/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="container">
  <div class="nav">
    <h2 style="margin-right:auto">Teacher Dashboard</h2>
    <a href="index.php">Get Back to Home Page</a>
    <a href="import_csv.php">Upload Data</a>
    <a href="link_parent_student.php">Link Parent with their Children</a>
    <a href="send_alerts_daily.php" target="_blank">Send Alerts Now</a>
    <a href="logout.php">Logout</a>
  </div>

  <div class="grid cols-2">
    <div>
      <h3>Risk Distribution</h3>
      <canvas id="riskPie"></canvas>
    </div>
    <div>
      <h3>Summary</h3>
      <ul>
        <li><span class="badge LOW">LOW</span> <span id="lowCount"><?= (int)$counts['LOW'] ?></span></li>
        <li><span class="badge MEDIUM">MEDIUM</span> <span id="medCount"><?= (int)$counts['MEDIUM'] ?></span></li>
        <li><span class="badge HIGH">HIGH</span> <span id="highCount"><?= (int)$counts['HIGH'] ?></span></li>
        <li><span class="badge">UNKNOWN</span> <span id="unkCount"><?= (int)$counts['UNKNOWN'] ?></span></li>
      </ul>
    </div>
  </div>

  <h3 style="margin-top:20px">Students (Latest Uploaded data)</h3>
  <table class="table" id="studentsTable">
    <tr>
      <th>Name</th>
      <th>Attendance %</th>
      <th>Avg Score</th>
      <th>Pending Fee</th>
      <th>Fee Status</th>
      <th>Risk</th></tr>
  
  </table>
</div>

<script>
let pie;
function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

function draw(data){
  const counts = [data.risk.LOW||0, data.risk.MEDIUM||0, data.risk.HIGH||0, data.risk.UNKNOWN||0];
  const ctx = document.getElementById('riskPie').getContext('2d');
  if(!pie){
    pie = new Chart(ctx, { type: 'pie', data:{ labels:['LOW','MEDIUM','HIGH','UNKNOWN'], datasets:[{data:counts, backgroundColor:['#10b981','#f59e0b','#ef4444','#64748b']}] }});
  } else { pie.data.datasets[0].data = counts; pie.update(); }

  document.getElementById('lowCount').innerText = data.risk.LOW||0;
  document.getElementById('medCount').innerText = data.risk.MEDIUM||0;
  document.getElementById('highCount').innerText = data.risk.HIGH||0;
  document.getElementById('unkCount').innerText = data.risk.UNKNOWN||0;

  const table = document.getElementById('studentsTable');
  table.innerHTML = `<tr><th>Name</th><th>Attendance %</th><th>Avg Score</th><th>Pending Fee</th><th>Fee Status</th><th>Risk</th></tr>` +
    data.students.map(s=>`<tr>
      <td>${escapeHtml(s.name)}</td>
      <td>${s.attendance_pct!=null?escapeHtml(s.attendance_pct)+'%':'—'}</td>
      <td>${s.avg_score!=null?escapeHtml(s.avg_score):'—'}</td>
      <td>${s.pending_fee!=null?escapeHtml(s.pending_fee):'0'}</td>
      <td>${escapeHtml(s.fee_due_status||'—')}</td>
      <td><span class="badge ${escapeHtml(s.risk_prediction)}">${escapeHtml(s.risk_prediction)}</span></td>
    </tr>`).join('');
}

async function refresh(){
  try {
    const r = await fetch('api_teacher_overview.php', {cache:'no-store'});
    if(r.ok){
      const data = await r.json();
      draw(data);
    }
  } catch(e){}
}

refresh();
setInterval(refresh, 30000);
</script>
</body></html> -->



<?php
require_once 'config.php';
require_once 'helpers.php';
include "lang_config.php"; 
require_login_role('teacher');
$counts = risk_counts($pdo);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title><?=$lang['teacher_dashboard']?></title>
  <link rel="stylesheet" href="assets/style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="container">
  <div class="nav">
    <h2 style="margin-right:auto"><?=$lang['teacher_dashboard']?></h2>
    <a href="index.php"><?=$lang['back_home']?></a>
    <a href="import_csv.php"><?=$lang['upload_data']?></a>
    <a href="link_parent_student.php"><?=$lang['link_parent']?></a>
    
    <a href="logout.php"><?=$lang['logout']?></a>
  </div>

  <div class="grid cols-2">
    <div>
      <h3><?=$lang['risk_distribution']?></h3>
      <canvas id="riskPie"></canvas>
    </div>
    <div>
      <h3><?=$lang['summary']?></h3>
      <ul>
        <li><span class="badge LOW">LOW</span> <span id="lowCount"><?= (int)$counts['LOW'] ?></span></li>
        <li><span class="badge MEDIUM">MEDIUM</span> <span id="medCount"><?= (int)$counts['MEDIUM'] ?></span></li>
        <li><span class="badge HIGH">HIGH</span> <span id="highCount"><?= (int)$counts['HIGH'] ?></span></li>
        <li><span class="badge">UNKNOWN</span> <span id="unkCount"><?= (int)$counts['UNKNOWN'] ?></span></li>
      </ul>
    </div>
  </div>

  <h3 style="margin-top:20px"><?=$lang['students_latest']?></h3>
  <table class="table" id="studentsTable">
    <tr>
      <th><?=$lang['name']?></th>
      <th><?=$lang['attendance']?></th>
      <th><?=$lang['avg_score']?></th>
      <th><?=$lang['pending_fee']?></th>
      <th><?=$lang['fee_status']?></th>
      <th><?=$lang['risk']?></th>
    </tr>
  </table>
</div>

<script>
let pie;
function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

function draw(data){
  const counts = [data.risk.LOW||0, data.risk.MEDIUM||0, data.risk.HIGH||0, data.risk.UNKNOWN||0];
  const ctx = document.getElementById('riskPie').getContext('2d');
  if(!pie){
    pie = new Chart(ctx, { 
      type: 'pie', 
      data:{ 
        labels:['LOW','MEDIUM','HIGH','UNKNOWN'], // You can also translate here if needed
        datasets:[{data:counts, backgroundColor:['#10b981','#f59e0b','#ef4444','#64748b']}] 
      } 
    });
  } else { 
    pie.data.datasets[0].data = counts; 
    pie.update(); 
  }

  document.getElementById('lowCount').innerText = data.risk.LOW||0;
  document.getElementById('medCount').innerText = data.risk.MEDIUM||0;
  document.getElementById('highCount').innerText = data.risk.HIGH||0;
  document.getElementById('unkCount').innerText = data.risk.UNKNOWN||0;

  const table = document.getElementById('studentsTable');
  table.innerHTML = `<tr>
    <th><?=$lang['name']?></th>
    <th><?=$lang['attendance']?></th>
    <th><?=$lang['avg_score']?></th>
    <th><?=$lang['pending_fee']?></th>
    <th><?=$lang['fee_status']?></th>
    <th><?=$lang['risk']?></th>
  </tr>` +
    data.students.map(s=>`<tr>
      <td>${escapeHtml(s.name)}</td>
      <td>${s.attendance_pct!=null?escapeHtml(s.attendance_pct)+'%':'—'}</td>
      <td>${s.avg_score!=null?escapeHtml(s.avg_score):'—'}</td>
      <td>${s.pending_fee!=null?escapeHtml(s.pending_fee):'0'}</td>
      <td>${escapeHtml(s.fee_due_status||'—')}</td>
      <td><span class="badge ${escapeHtml(s.risk_prediction)}">${escapeHtml(s.risk_prediction)}</span></td>
    </tr>`).join('');
}

async function refresh(){
  try {
    const r = await fetch('api_teacher_overview.php', {cache:'no-store'});
    if(r.ok){
      const data = await r.json();
      draw(data);
    }
  } catch(e){}
}

refresh();
setInterval(refresh, 30000);
</script>
</body>
</html>