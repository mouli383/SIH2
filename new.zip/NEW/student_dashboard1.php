<!-- <?php
require_once 'config.php';
session_start();
if(empty($_SESSION['student_id'])){
    header('Location: student_login.php'); exit;
}

$student_id = $_SESSION['student_id'];
$student_name = $_SESSION['student_name'];

// fetch latest snapshot
$sql = "SELECT * FROM student_snapshots WHERE student_id=? ORDER BY snapshot_date DESC LIMIT 1";
$stmt = $pdo->prepare($sql);
$stmt->execute([$student_id]);
$snapshot = $stmt->fetch();
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Dashboard</title></head>
<body>
<h2>Welcome <?=htmlspecialchars($student_name)?></h2>

<?php if($snapshot): ?>
<table border="1">
<tr><th>Date</th><td><?=htmlspecialchars($snapshot['snapshot_date'])?></td></tr>
<tr><th>Attendance %</th><td><?=$snapshot['attendance_pct']?>%</td></tr>
<tr><th>Average Score</th><td><?=$snapshot['avg_score']?></td></tr>
<tr><th>Pending Fee</th><td>₹<?=$snapshot['pending_fee']?></td></tr>
<tr><th>Risk Prediction</th><td><?=$snapshot['risk_prediction']?></td></tr>
</table>
<?php else: ?>
<p>No academic records uploaded yet.</p>
<?php endif; ?>

<a href="logout.php">Logout</a>
</body>
</html> -->


<!-- <?php 
require_once 'config.php'; 
session_start(); 
if(empty($_SESSION['student_id'])){ 
    header('Location: student_login.php'); 
    exit; 
} 
$student_id = $_SESSION['student_id']; 
$student_name = $_SESSION['student_name']; 

// latest snapshot
$sql = "SELECT * FROM student_snapshots WHERE student_id=? ORDER BY snapshot_date DESC LIMIT 1"; 
$stmt = $pdo->prepare($sql); 
$stmt->execute([$student_id]); 
$snapshot = $stmt->fetch(); 

// last 5 snapshots for chart
$hist = $pdo->prepare("SELECT snapshot_date, avg_score FROM student_snapshots WHERE student_id=? ORDER BY snapshot_date DESC LIMIT 5"); 
$hist->execute([$student_id]); 
$rows = array_reverse($hist->fetchAll()); 
$dates = array_column($rows,'snapshot_date'); 
$scores = array_column($rows,'avg_score'); 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Student Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    body{font-family: Arial, sans-serif; background:#eef2f7; margin:0; padding:0;}
    .container{width:80%; margin:30px auto; background:#fff; padding:20px; border-radius:10px; box-shadow:0 4px 10px rgba(0,0,0,0.1);}
    h2{color:#333; text-align:center;}
    table{width:100%; border-collapse:collapse; margin-top:20px;}
    th,td{padding:12px; text-align:left; border-bottom:1px solid #ddd;}
    th{background:#5ac8fa; color:white;}
    tr:hover{background:#f9f9f9;}
    .btn{display:inline-block; margin-top:20px; padding:10px 20px; background:#5ac8fa; color:#fff; text-decoration:none; border-radius:5px;}
    .btn:hover{background:#349fd6;}
    .chart-box{margin-top:40px;}
</style>
</head>
<body>
<div class="container">
  <h2>Welcome <?=htmlspecialchars($student_name)?></h2>

  <?php if($snapshot): ?>
  <table>
    <tr><th>Date</th><td><?=htmlspecialchars($snapshot['snapshot_date'])?></td></tr>
    <tr><th>Attendance %</th><td><?=$snapshot['attendance_pct']?>%</td></tr>
    <tr><th>Average Score</th><td><?=$snapshot['avg_score']?></td></tr>
    <tr><th>Pending Fee</th><td>₹<?=$snapshot['pending_fee']?></td></tr>
    <tr><th>Risk Prediction</th><td><?=$snapshot['risk_prediction']?></td></tr>
  </table>
  <?php else: ?>
  <p>No academic records uploaded yet.</p>
  <?php endif; ?>

  <div class="chart-box">
    <h3 style="text-align:center;">Performance Trend (Last 5 Records)</h3>
    <canvas id="scoreChart"></canvas>
  </div>

  <a href="logout.php" class="btn">Logout</a>
</div>

<script>
const ctx = document.getElementById('scoreChart').getContext('2d');
new Chart(ctx, {
  type: 'line',
  data: {
    labels: <?=json_encode($dates)?>,
    datasets: [{
      label: 'Average Score',
      data: <?=json_encode($scores)?>,
      borderColor: '#5ac8fa',
      backgroundColor: 'rgba(90,200,250,0.2)',
      tension: 0.3,
      fill: true,
      pointRadius: 5,
      pointBackgroundColor: '#349fd6'
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: { display: true, labels: { color:'#333', font:{size:14} } }
    },
    scales: {
      x: { title:{display:true, text:"Date"} },
      y: { beginAtZero:true, max:100, title:{display:true, text:"Score"} }
    }
  }
});
</script>
</body>
</html>  -->

<?php 
include "lang_config.php"; 
// session_start(); 
if(empty($_SESSION['student_id'])){ 
    header('Location: student_login.php'); 
    exit; 
} 
$student_id = $_SESSION['student_id']; 
$student_name = $_SESSION['student_name']; 

// latest snapshot
$sql = "SELECT * FROM student_snapshots WHERE student_id=? ORDER BY snapshot_date DESC LIMIT 1"; 
$stmt = $pdo->prepare($sql); 
$stmt->execute([$student_id]); 
$snapshot = $stmt->fetch(); 

// last 5 snapshots for chart
$hist = $pdo->prepare("SELECT snapshot_date, avg_score FROM student_snapshots WHERE student_id=? ORDER BY snapshot_date DESC LIMIT 5"); 
$hist->execute([$student_id]); 
$rows = array_reverse($hist->fetchAll()); 
$dates = array_column($rows,'snapshot_date'); 
$scores = array_column($rows,'avg_score'); 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?=$lang['student_dashboard']?></title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="assets/style.css">
<style>
     .back-button{
    margin-top:20px;
    /* text-align:center; */
    margin-left:15px;
}
.back-button a {
    text-decoration:none;
    padding:12px 25px;
    background-color:#10b981;
    color:#fff;
    font-size:16px;
    border-radius:8px;
    box-shadow:0 4px 12px rgba(0,0,0,0.3);
    transition:0.3s;
}
.back-button a:hover{
    background-color:#0f9d75;
    transform:translateY(-2px);
}
</style>
</head>
<body>
<div class="container">
  <h2><?=$lang['welcome']?> <?=htmlspecialchars($student_name)?></h2>


  <table border="1">
    <tr><th><?=$lang['date']?></th><td><?=htmlspecialchars($snapshot['snapshot_date'])?></td></tr>
    <tr><th><?=$lang['attendance']?></th><td><?=$snapshot['attendance_pct']?>%</td></tr>
    <tr><th><?=$lang['avg_score']?></th><td><?=$snapshot['avg_score']?></td></tr>
    <tr><th><?=$lang['pending_fee']?></th><td>₹<?=$snapshot['pending_fee']?></td></tr>
    <tr><th><?=$lang['risk']?></th><td><?=$snapshot['risk_prediction']?></td></tr>
  </table>
  <br/><br/>
  <div class="back-button">
     <!-- <a href="index.php"><?=$lang['back_home']?></a> -->
      <a href="student_new.php">Back To Dashboard</a>
  </div>
 
  
</body>
</html>