<!-- <?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('teacher');
if($_SERVER['REQUEST_METHOD']==='POST'){
    $parent_email = trim($_POST['parent_email']);
    $student_ext = trim($_POST['student_id_external']);
    $p = $pdo->prepare("SELECT id FROM users WHERE email=? AND role='parent' LIMIT 1"); 
    $p->execute([$parent_email]); 
    $parent = $p->fetch();
    $s = $pdo->prepare("SELECT id FROM students WHERE student_id_external=? LIMIT 1"); 
    $s->execute([$student_ext]); 
    $stud = $s->fetch();
    if($parent && $stud){
        $ins = $pdo->prepare("INSERT IGNORE INTO parent_students (parent_user_id, student_id) VALUES (?,?)");
        $ins->execute([$parent['id'],$stud['id']]);
        $msg = "Linked successfully.";
    } else $err = "Parent or Student not found.";
}
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
  <title>Link Parent & Student</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="center">
<div class="card">
  <h2>Link Parent and Student</h2>
<?php if(!empty($msg)) echo "<p class='ok'>".htmlspecialchars($msg)."</p>"; if(!empty($err)) echo "<p class='err'>".htmlspecialchars($err)."</p>"; ?>
<form method="post">
  <input name="parent_email" type="email" placeholder="Parent Email" required>
  <input name="student_id_external" placeholder="Student External ID" required>
  <button>Link</button>
</form>
<p><a href="teacher_dashboard.php">Back to Dashboard</a></p>
</div>
</body>
</html> -->

<?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('teacher');
include "lang_config.php"; // 🔑 add multilanguage support

if($_SERVER['REQUEST_METHOD']==='POST'){
    $parent_email = trim($_POST['parent_email']);
    $student_ext = trim($_POST['student_id_external']);

    $p = $pdo->prepare("SELECT id FROM users WHERE email=? AND role='parent' LIMIT 1"); 
    $p->execute([$parent_email]); 
    $parent = $p->fetch();

    $s = $pdo->prepare("SELECT id FROM students WHERE student_id_external=? LIMIT 1"); 
    $s->execute([$student_ext]); 
    $stud = $s->fetch();

    if($parent && $stud){
        $ins = $pdo->prepare("INSERT IGNORE INTO parent_students (parent_user_id, student_id) VALUES (?,?)");
        $ins->execute([$parent['id'],$stud['id']]);
        $msg = $lang['link_success']; // 🔑 multilanguage
    } else {
        $err = $lang['link_error'];   // 🔑 multilanguage
    }
}
?>
<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <title><?=$lang['link_parent_student']?></title>
    <link rel="stylesheet" href="assets/style.css">
  </head>
  <body class="center">
    <div class="card">
      <h2><?=$lang['link_parent_student']?></h2>

      <?php 
      if(!empty($msg)) echo "<p class='ok'>".htmlspecialchars($msg)."</p>"; 
      if(!empty($err)) echo "<p class='err'>".htmlspecialchars($err)."</p>"; 
      ?>

      <form method="post">
        <input name="parent_email" type="email" placeholder="<?=$lang['parent_email']?>" required>
        <input name="student_id_external" placeholder="<?=$lang['student_external_id']?>" required>
        <button><?=$lang['link_btn']?></button>
      </form>

      <p><a href="teacher_dashboard.php"><?=$lang['back_dashboard']?></a></p>

      <!-- Language switcher (optional) -->

      
      
    </div>
  </body>
</html>
