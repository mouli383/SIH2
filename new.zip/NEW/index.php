<!-- <?php

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>AI Dropout Prediction System</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    body {
      display:flex;
      flex-direction:column;
      justify-content:space-between;
      align-items:center;
      min-height:100vh;
      margin:0;
      background:"white";
      color:#f0f0f0;
      font-family:Arial, sans-serif;
      text-align:center;
    }
    header {
      width:100%;
      padding:20px;
      background:#1a2235;
      display:flex;
      justify-content:space-between;
      align-items:center;
      box-shadow:0 2px 6px rgba(0,0,0,0.4);
    }
    header h1 {
      margin:0;
      font-size:22px;
      color:#5ac8fa;
      text-align:center;
    }
    .profile-icon {
      width:40px;
      height:40px;
      border-radius:50%;
      background:#5ac8fa;
      display:flex;
      justify-content:center;
      align-items:center;
      font-weight:bold;
      color:#0f1724;
      cursor:pointer;
    }
    main {
      flex-grow:1;
     
    }
    main div{
        border:2px solid white;
        width:250px;
        height:250px;
        border-radius:20px;
        display:flex;
        flex-direction:column;
        justify-content:center;
        align-items:center;
        margin-top:10px;
    }
    .btn-container {
      width:700px;
      padding:20px;
      display:flex;
      justify-content:space-around;

    }
    .btn {
      padding:14px 26px;
      border:none;
      border-radius:8px;
      font-size:22px;
      font-weight:bold;
      cursor:pointer;
  
      margin-right:20px;
    }
    .btn-teacher {
      background:#5ac8fa;
      color:#0f1724;
    }
    .btn-teacher:hover{
        background-color:white;
        color:#5ac8fa;
        box-shadow:2px 2px 2px #5ac8fa;
    }
    .btn-parent {
      background:#34c759;
      color:#0f1724;
    }
    .btn-parent:hover{
        background-color:white;
        color:#34c759;
        box-shadow:2px 2px 2px #34c759;
    }
    .btn:hover {
      opacity:0.9;
    }
    footer {
      padding:10px;
      font-size:13px;
      color:#888;
      margin-bottom:36px;
    }
  </style>
</head>
<body>
  <header>
    <h1 style="text-align:center">EduSafe AI</h1>
    <div class="profile-icon">👤</div>
  </header>

  <main>
    <marquee scroll-amount="500"><h2>Welcome</h2></marquee>
    <div>
        
        <p>Predict, Prevent & Support Student Success</p>
    </div>
    
  </main>

  <div class="btn-container">
    <button class="btn btn-teacher" onclick="location.href='teacher_login.php'">Teacher Login</button>
    <button class="btn btn-parent" onclick="location.href='parent_login.php'">Parent Login</button>
    <button class="btn btn-parent" onclick="location.href='student_login.php'">Student Login</button>
  </div>

  <footer>&copy; <?php date('Y')?> Smart India Hackathon Project</footer>
</body>
</html> -->


<!-- <?php
session_start();

// language selection
if(isset($_GET['lang'])){
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: index.php"); // refresh
    exit;
}

// default English
if(!isset($_SESSION['lang'])) $_SESSION['lang'] = "en";

// load language file
include "lang/".$_SESSION['lang'].".php";
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>AI Dropout Prediction System</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    body {
      display:flex;
      flex-direction:column;
      justify-content:space-between;
      align-items:center;
      min-height:100vh;
      margin:0;
      background:#ffffff;
      color:#0f1724;
      font-family:Arial, sans-serif;
      text-align:center;
    }
    header {
      width:100%;
      padding:20px;
      background:#1a2235;
      display:flex;
      justify-content:space-between;
      align-items:center;
      box-shadow:0 2px 6px rgba(0,0,0,0.4);
    }
    header h1 {
      margin:0;
      font-size:22px;
      color:#5ac8fa;
    }
    .profile-icon {
      width:40px;
      height:40px;
      border-radius:50%;
      background:#5ac8fa;
      display:flex;
      justify-content:center;
      align-items:center;
      font-weight:bold;
      color:#0f1724;
      cursor:pointer;
    }
    .lang-switch a {
      color:#fff;
      text-decoration:none;
      margin:0 5px;
      font-weight:bold;
    }
    .lang-switch a:hover {
      text-decoration:underline;
    }
    main {
      flex-grow:1;
    }
    main div{
        border:2px solid white;
        width:250px;
        height:250px;
        border-radius:20px;
        display:flex;
        flex-direction:column;
        justify-content:center;
        align-items:center;
        margin-top:10px;
    }
    .btn-container {
      width:700px;
      padding:20px;
      display:flex;
      justify-content:space-around;
    }
    .btn {
      padding:14px 26px;
      border:none;
      border-radius:8px;
      font-size:22px;
      font-weight:bold;
      cursor:pointer;
      margin-right:20px;
    }
    .btn-teacher {
      background:#5ac8fa;
      color:#0f1724;
    }
    .btn-teacher:hover{
        background-color:white;
        color:#5ac8fa;
        box-shadow:2px 2px 2px #5ac8fa;
    }
    .btn-parent {
      background:#34c759;
      color:#0f1724;
    }
    .btn-parent:hover{
        background-color:white;
        color:#34c759;
        box-shadow:2px 2px 2px #34c759;
    }
    footer {
      padding:10px;
      font-size:13px;
      color:#888;
      margin-bottom:36px;
    }
  </style>
</head>
<body>
  <header>
    <h1>EduSafe AI</h1>
    <div style="display:flex; gap:15px; align-items:center;">
      <div class="lang-switch">
        <a href="?lang=en">EN</a>|
        <a href="?lang=te">TE</a>|
        <a href="?lang=hi">HI</a>
      </div>
      <div class="profile-icon">👤</div>
    </div>
  </header>

  <main>
    <marquee scroll-amount="500"><h2><?=$lang['welcome']?></h2></marquee>
    <div>
        <p><?=$lang['tagline']?></p>
    </div>
  </main>

  <div class="btn-container">
    <button class="btn btn-teacher" onclick="location.href='teacher_login.php'"><?=$lang['teacher_login']?></button>
    <button class="btn btn-parent" onclick="location.href='parent_login.php'"><?=$lang['parent_login']?></button>
    <button class="btn btn-parent" onclick="location.href='student_login.php'"><?=$lang['student_login']?></button>
  </div>

  <footer>&copy; <?=date('Y')?> Smart India Hackathon Project</footer>
</body>
</html> -->

<?php
// session_start();

// language selection
if(isset($_GET['lang'])){
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: index.php"); // refresh
    exit;
}

// default English
if(!isset($_SESSION['lang'])) $_SESSION['lang'] = "en";

// load language file
include "lang/".$_SESSION['lang'].".php";
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>AI Dropout Prediction System</title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    /* --- Your existing styles untouched --- */
    body {
      display:flex;
      flex-direction:column;
      justify-content:space-between;
      align-items:center;
      min-height:100vh;
      margin:0;
      background:"white";
      color:#f0f0f0;
      font-family:Arial, sans-serif;
      text-align:center;
    }
    header {
      width:100%;
      padding:20px;
      background:#1a2235;
      display:flex;
      justify-content:space-between;
      align-items:center;
      box-shadow:0 2px 6px rgba(0,0,0,0.4);
    }
    header h1 {
      margin:0;
      font-size:22px;
      color:#5ac8fa;
      text-align:center;
    }
    .profile-icon {
      width:40px;
      height:40px;
      border-radius:50%;
      background:#5ac8fa;
      display:flex;
      justify-content:center;
      align-items:center;
      font-weight:bold;
      color:#0f1724;
      cursor:pointer;
    }
    main {
      flex-grow:1;
    }
    main div{
        border:2px solid white;
        width:250px;
        height:250px;
        border-radius:20px;
        display:flex;
        flex-direction:column;
        justify-content:center;
        align-items:center;
        margin-top:10px;
    }
    .btn-container {
      width:700px;
      padding:20px;
      display:flex;
      justify-content:space-around;
    }
    .btn {
      padding:14px 26px;
      border:none;
      border-radius:8px;
      font-size:22px;
      font-weight:bold;
      cursor:pointer;
      margin-right:20px;
    }
    .btn-teacher {
      background:#5ac8fa;
      color:#0f1724;
    }
    .btn-teacher:hover{
        background-color:white;
        color:#5ac8fa;
        box-shadow:2px 2px 2px #5ac8fa;
    }
    .btn-parent {
      background:#34c759;
      color:#0f1724;
    }
    .btn-parent:hover{
        background-color:white;
        color:#34c759;
        box-shadow:2px 2px 2px #34c759;
    }
    footer {
      padding:10px;
      font-size:13px;
      color:#888;
      margin-bottom:36px;
    }
    /* --- new small styles only for language toggle --- */
    .lang-switch a {
      color:white;
      margin:0 5px;
      text-decoration:none;
      font-weight:bold;
    }
    .lang-switch a:hover { text-decoration:underline; }
  </style>
</head>
<body>
  <header>
    <h1 style="text-align:center">EduSafe AI</h1>
    <div style="display:flex; gap:15px; align-items:center;">
      <div class="lang-switch">
        <a href="?lang=en">ENGLISH</a>|
        <a href="?lang=te">TELUGU</a>|
        <a href="?lang=hi">HINDI</a>
      </div>
      <div class="profile-icon">👤</div>
    </div>
  </header>

  <main>
    <marquee scroll-amount="500"><h2><?=$lang['welcome']?></h2></marquee>
    <div>
        <p><?=$lang['tagline']?></p>
    </div>
  </main>

  <div class="btn-container">
    <button class="btn btn-success" onclick="location.href='teacher_login.php'"><?=$lang['admin_login_title']?></button>
    <button class="btn btn-success" onclick="location.href='parent_login.php'"><?=$lang['parent_login']?></button>
    <button class="btn btn-success" onclick="location.href='mentor_login.php'"><?=$lang['mentor_login']?></button>
    <button class="btn btn-success" onclick="location.href='student_login1.php'"><?=$lang['student_login']?></button>
  </div>

  <footer>&copy; <?=date('Y')?> Smart India Hackathon Project</footer>
</body>
</html>