<?php
// $DB_HOST = "sql100.infinityfree.com";
// $DB_NAME = "if0_39947378_dropoutprediction";
// $DB_USER ="if0_39947378";
// $DB_PASS = "Mvux8OaHkZqwue";

$DB_HOST = "";
$DB_NAME = "dashboard";
$DB_USER = "root";
$DB_PASS = "";

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("DB connection failed: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// API Key define only once
if (!defined('API_KEY')) {
    define('API_KEY', 'EduSafeAI_SecretKey_9@7$4!1q'); 
}

// Safe function definitions
if (!function_exists('is_logged')) {
    function is_logged() {
        return isset($_SESSION['user_id']);
    }
}

if (!function_exists('require_login_role')) {
    function require_login_role($role) {
        if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== $role) {
            header('Location: ' . ($role === 'teacher' ? 'teacher_login.php' : 'parent_login.php'));
            exit;
        }
    }
}

// Mail config
$MAIL = [
    'enabled' => true,
    'use_phpmailer' => false, 
    'host' => 'smtp.example.com',
    'port' => 587,
    'secure' => 'tls',
    'username' => 'no-reply@example.com',
    'password' => 'SMTP_PASSWORD',
    'from_email' => 'no-reply@example.com',
    'from_name' => 'School Alerts'
];

// Twilio config
$TWILIO = [
    'enabled' => false,
    'sid' => 'TWILIO_SID',
    'token' => 'TWILIO_TOKEN',
    'from'  => '+1234567890'
];

$BASE_URL = 'http://localhost';