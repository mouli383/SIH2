<?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('teacher');
header('Content-Type: application/json');
$rc = risk_counts($pdo);
$students = get_latest_snapshots($pdo);
$out = ['risk'=>$rc, 'students'=>array_map(function($s){
    return [
        'name'=>$s['full_name'],
        'attendance_pct'=>$s['attendance_pct'],
        'avg_score'=>$s['avg_score'],
        'pending_fee'=>$s['pending_fee'],
        'fee_due_status'=>$s['fee_due_status'] ?? null,
        'risk_prediction'=>$s['risk_prediction'] ?? 'UNKNOWN'
    ];
}, $students)];
echo json_encode($out);
