<!--  -->

<?php
require_once 'config.php';
include "lang_config.php";
// session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fetch all mentors
$mentors = $pdo->query("SELECT id, name FROM users WHERE role='mentor'")->fetchAll();

// Fetch students NOT already linked
$sql = "
    SELECT s.id, s.full_name 
    FROM students s
    WHERE s.id NOT IN (SELECT student_id FROM mentor_students)
";
$students = $pdo->query($sql)->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mentor_id = $_POST['mentor_id'];
    $student_ids = $_POST['student_ids'] ?? [];

    // Insert links (without deleting previous ones)
    $stmt = $pdo->prepare("INSERT IGNORE INTO mentor_students (mentor_user_id, student_id, created_at) VALUES (?, ?, NOW())");

    foreach ($student_ids as $sid) {
        $stmt->execute([$mentor_id, $sid]);
    }

    $msg = $lang['link_success'];

    // Refresh dropdown → hide newly linked students
    $students = $pdo->query($sql)->fetchAll();
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title><?=$lang['link_mentor']?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="center">
<div class="card" style="width:500px;text-align:left;">
  <h2><?=$lang['link_mentor']?></h2>

  <?php if (!empty($msg)) echo "<p class='success'>".htmlspecialchars($msg)."</p>"; ?>

  <form method="post">
    <label><?=$lang['select_mentor']?></label><br>
    <select name="mentor_id" required>
      <option value=""><?=$lang['choose']?></option>
      <?php foreach($mentors as $m): ?>
        <option value="<?=$m['id']?>"><?=htmlspecialchars($m['name'])?></option>
      <?php endforeach; ?>
    </select><br><br>

    <label><?=$lang['select_students']?></label><br>
    <select name="student_ids[]" multiple size="8" style="width:100%">
      <?php foreach($students as $s): ?>
        <option value="<?=$s['id']?>"><?=htmlspecialchars($s['full_name'])?></option>
      <?php endforeach; ?>
    </select><br><br>

    <button><?=$lang['save']?></button>

     <a href="index.php"><?=$lang['back_home']?></a>
  </form>
</div>
</body>
</html>
