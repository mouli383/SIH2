<?php 
    $servername="sql100.infinityfree.com";
    $username="if0_39947378";
    $password="Mvux8OaHkZqwue";
    $dbname="if0_39947378_dropoutprediction";

    $conn=new mysqli($servername,$username,$password,$dbname);

    if($conn->connect_error){
        die("Connection failed: ".$conn->connect_error);
    }
    echo "Connected Successfully"
?>