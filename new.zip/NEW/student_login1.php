<?php 
include 'config.php';
include "lang_config.php"; 
// session_start();

if($_SERVER['REQUEST_METHOD']==='POST'){ 
    $sid = trim($_POST['student_id']); 
    $st = $pdo->prepare("SELECT id, full_name FROM students WHERE student_id_external=? LIMIT 1"); 
    $st->execute([$sid]); 
    $student = $st->fetch(); 
    if($student){ 
        $_SESSION['student_id'] = $student['id']; 
        $_SESSION['student_name'] = $student['full_name']; 
        $_SESSION['user_id'] = $student['id'];
        $_SESSION['user_role'] = 'student';
        header('Location: student_new.php'); 
        exit; 
    } else { 
        $err = $lang['invalid_id'] ?? 'Invalid Student ID';
    }
} 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($lang['student_login'] ?? 'Student Login') ?></title>
<link rel="stylesheet" href="assets/style.css">
<style>
/* === Parent login style variables === */
:root{
  --bg:#0b1020; --card:#0f1724; --muted:#9fb0c4; --txt:#eaf2f8;
  --ok:#10b981; --warn:#f59e0b; --bad:#ef4444; --link:#60a5fa;
}
*{box-sizing:border-box;}
body{
  margin:0;
  font-family:Inter,system-ui,Segoe UI,Roboto,Arial;
  background:var(--bg);
  color:var(--txt);
}
.center{
  display:grid;
  place-items:center;
  min-height:100vh;
  padding:20px;
}
.card{
  background:var(--card);
  padding:24px;
  border-radius:12px;
  box-shadow:0 10px 30px rgba(0,0,0,.5);
  width:min(520px,96vw);
  text-align:center;
}
.card h2{
  margin-bottom:20px;
}
input,button{
  width:100%;
  padding:10px 12px;
  border-radius:10px;
  border:1px solid #223148;
  background:#0d1524;
  color:var(--txt);
  margin:.5rem 0;
}
button{
  cursor:pointer;
  background:#2563eb;
  border:0;
}
.err{
  color:var(--bad);
  margin-bottom:10px;
}
.language-switcher{
  margin-top:12px;
}
.language-switcher a{
  margin:0 8px;
  text-decoration:none;
  color:var(--link);
}
.language-switcher a:hover{
  text-decoration:underline;
}
</style>
</head>
<body>
<div class="center">
  <div class="card">
    <h2><?= htmlspecialchars($lang['student_login'] ?? 'Student Login') ?></h2>
    <?php if(!empty($err)) echo "<p class='err'>".htmlspecialchars($err)."</p>"; ?>
    <form method="post">
      <input name="student_id" placeholder="<?= htmlspecialchars($lang['enter_id'] ?? 'Enter Student ID') ?>" required>
      <button><?= htmlspecialchars($lang['login'] ?? 'Login') ?></button>
    </form>

    <!-- <div class="language-switcher">
        <a href="?lang=en">English</a> | 
        <a href="?lang=te">తెలుగు</a> | 
        <a href="?lang=hi">हिन्दी</a>
    </div> -->
    <div class="language-switcher">
            <a href="?lang=en">English</a> | 
            <a href="?lang=te">తెలుగు</a> | 
            <a href="?lang=hi">हिन्दी</a>
        </div>

    <p><a href="index.php"><?=$lang['back_home']?></a></p>
  </div>
</div>
</body>
</html>






