<?php
// session_start();

// language selection from query string
if(isset($_GET['lang'])){
    $_SESSION['lang'] = $_GET['lang'];
    header("Location: ".$_SERVER['PHP_SELF']); // reload current page
    exit;
}

// default = English
if(!isset($_SESSION['lang'])) $_SESSION['lang'] = "en";

// include language file
// include (_DIR_ . "/lang/" . $_SESSION['lang'] . ".php");
$langFile = __DIR__ . "/lang/" . $_SESSION['lang'] . ".php";
if(file_exists($langFile)){
    include $langFile;
} else {
    include __DIR__ . "/lang/en.php"; // fallback English
}