


<?php 
require_once 'config.php'; 
include "lang_config.php"; 
// session_start();

if($_SERVER['REQUEST_METHOD']==='POST'){
    $email = trim($_POST['email']);
    $pass = $_POST['password'];
    $st = $pdo->prepare("SELECT * FROM users WHERE email=? AND role='teacher' LIMIT 1");
    $st->execute([$email]); 
    $u = $st->fetch();
    if($u && password_verify($pass, $u['password_hash'])){
        $_SESSION['user_id'] = $u['id'];
        $_SESSION['user_name'] = $u['name'];
        $_SESSION['user_role'] = 'teacher';
        header('Location: constraint.html'); 
        exit;
    } else $err = $lang['invalid_credentials'];
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title><?=$lang['teacher_login']?></title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    a{
      font-size:16px;
    }
  </style>
</head>
<body class="center">
<div class="card">
  <h2><?=$lang['teacher_login']?></h2>
  <?php if(!empty($err)) echo "<p class='err'>".htmlspecialchars($err)."</p>"; ?>
  <form method="post">
    <input name="email" type="email" placeholder="<?=$lang['email']?>" required>
    <input name="password" type="password" placeholder="<?=$lang['password']?>" required>
    <button href="admin_constraint.php"><?=$lang['login']?></button>
  </form>
  <p>
    <a href="register_teacher.php"><?=$lang['create_teacher']?></a>  &nbsp;&nbsp;&nbsp;
    |&nbsp;&nbsp;&nbsp;<a href="register_mentor.php"><?=$lang['create_mentor']?></a><br/>
   <a href="link_mentor_students.php">Link Student With Mentor</a> &nbsp;&nbsp;&nbsp;|
    &nbsp;&nbsp;&nbsp;<a href="index.php"><?=$lang['back_home']?></a>

    <!-- <a href="import_csv.php"><?=$lang['import_csv']?></a> -->
  </p>


</div>
</body>
</html>