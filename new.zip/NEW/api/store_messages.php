<!--  -->



<?php
// api/store_message.php
require_once _DIR_ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

session_start();

// Accept either session auth or API key auth
$api_key = $_SERVER['HTTP_X_API_KEY'] ?? '';
$has_api_auth = defined('API_KEY') && hash_equals(API_KEY, (string)$api_key);
$has_session_auth = isset($_SESSION['user_id']);

if (!$has_api_auth && !$has_session_auth) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
if (!$body) { 
    http_response_code(400); 
    echo json_encode(['error'=>'invalid json']); 
    exit; 
}

$message = trim($body['message'] ?? '');
$student_id = (int)($body['student_id'] ?? 0);

$sender_role = $body['sender_role'] ?? ($_SESSION['user_role'] ?? null);
$sender_id = isset($body['sender_id']) ? (int)$body['sender_id'] : ($_SESSION['user_id'] ?? 0);
$recipient_role = $body['recipient_role'] ?? null;
$recipient_id = isset($body['recipient_id']) ? (int)$body['recipient_id'] : null;

if ($message === '' || $student_id <= 0 || !$sender_role || $sender_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'missing fields']);
    exit;
}

$meta = isset($body['metadata']) ? json_encode($body['metadata']) : null;

$stmt = $pdo->prepare("
    INSERT INTO chat_messages 
    (sender_role, sender_id, recipient_role, recipient_id, student_id, message, metadata, created_at) 
    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
");
$stmt->execute([$sender_role, $sender_id, $recipient_role, $recipient_id, $student_id, $message, $meta]);

echo json_encode([
    'success' => true, 
    'message_id' => (int)$pdo->lastInsertId()
]);