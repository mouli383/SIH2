<?php
// api/get_student_context.php
require_once _DIR_ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

// API key check
$api_key = $_SERVER['HTTP_X_API_KEY'] ?? '';
if (!hash_equals(API_KEY, (string)$api_key)) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$student_id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
if ($student_id <= 0) { http_response_code(400); echo json_encode(['error'=>'invalid student_id']); exit; }

$stmt = $pdo->prepare("
  SELECT id, student_id_external, full_name, class, attendance_pct, avg_score, pending_fee, fee_due_status, risk_prediction
  FROM students WHERE id = ? LIMIT 1
");
$stmt->execute([$student_id]);
$s = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$s) { http_response_code(404); echo json_encode(['error'=>'not found']); exit; }

echo json_encode(['student' => $s]);