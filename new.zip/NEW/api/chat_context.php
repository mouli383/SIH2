<?php
// api/chat_context.php
require_once _DIR_ . '/../config.php';
session_start();
header('Content-Type: application/json; charset=utf-8');

// Require logged-in student
if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] ?? '') !== 'student') {
    http_response_code(403);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}
$student_id = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare("
  SELECT id, student_id_external, full_name, class, attendance_pct, avg_score, pending_fee, fee_due_status, risk_prediction
  FROM students WHERE id = ? LIMIT 1
");
$stmt->execute([$student_id]);
$s = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$s) { http_response_code(404); echo json_encode(['error'=>'not found']); exit; }

echo json_encode(['student' => $s]);