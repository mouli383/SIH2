<!--  -->


<?php
// api/get_messages.php
require_once _DIR_ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');

session_start();

// Accept API key or session
$api_key = $_SERVER['HTTP_X_API_KEY'] ?? '';
$has_api_auth = defined('API_KEY') && hash_equals(API_KEY, (string)$api_key);
$has_session_auth = isset($_SESSION['user_id']);

if (!$has_api_auth && !$has_session_auth) {
    http_response_code(401);
    echo json_encode(['error' => 'unauthorized']);
    exit;
}

$student_id = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
$limit = isset($_GET['limit']) ? min(500, (int)$_GET['limit']) : 200;

if ($student_id <= 0) {
    if ($has_session_auth && ($_SESSION['user_role'] === 'student')) {
        $student_id = (int)$_SESSION['user_id'];
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'invalid student_id']);
        exit;
    }
}

// Prepare query (LIMIT cannot be bound with ? placeholder)
$sql = "SELECT id, sender_role, sender_id, recipient_role, recipient_id, message, metadata, created_at 
        FROM chat_messages 
        WHERE student_id = ? 
        ORDER BY created_at ASC 
        LIMIT $limit";
$stmt = $pdo->prepare($sql);
$stmt->execute([$student_id]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['messages' => $rows]);