

 <?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('teacher');
include "lang_config.php"; // 🔑 multilanguage support

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $tmp = $_FILES['csv_file']['tmp_name'];
    if (!is_uploaded_file($tmp)) { $msg = $lang['upload_failed']; }
    else {
        if (($fh = fopen($tmp, 'r')) !== false) {
            $header = fgetcsv($fh);
            if (!$header) { $msg = $lang['empty_csv']; fclose($fh); }
            else {
                $keys = array_map(function($h){ return strtolower(trim($h)); }, $header);
                $count = 0; $errors = 0;
                while (($row = fgetcsv($fh, 0, ',')) !== false) {
                    if (count($row) === 0) continue;
                    $rec = array_combine($keys, $row);
                    if (!$rec) { $errors++; continue; }
                    $ext = trim($rec['student_id'] ?? '');
                    $name = trim($rec['name'] ?? '');
                    if ($ext === '' || $name === '') { $errors++; continue; }

                    $sid = ensure_student($pdo, $ext, $name, $rec['class'] ?? null, $rec['guardian_email'] ?? null);

                    $snapshot_date = trim($rec['snapshot_date'] ?? '') ?: date('Y-m-d');

                    $snap = [
                        'student_id' => $sid,
                        'snapshot_date' => $snapshot_date,
                        'total_classes' => $rec['total_classes'] ?? null,
                        'attended_classes' => $rec['attended_classes'] ?? null,
                        'attendance_pct' => $rec['attendance_%'] ?? ($rec['attendance_pct'] ?? null),
                        'test1' => $rec['test1'] ?? null,
                        'test2' => $rec['test2'] ?? null,
                        'test3' => $rec['test3'] ?? null,
                        'avg_score' => $rec['avg_score'] ?? null,
                        'score_trend' => $rec['score_trend'] ?? null,
                        'total_fee' => $rec['total_fee'] ?? null,
                        'paid_fee' => $rec['paid_fee'] ?? null,
                        'pending_fee' => $rec['pending_fee'] ?? null,
                        'fee_due_status' => $rec['fee_due_status'] ?? null,
                        'risk_prediction' => $rec['risk_prediction'] ?? null,
                        'raw_json' => json_encode($rec, JSON_UNESCAPED_UNICODE)
                    ];

                    if (empty($snap['risk_prediction'])) {
                        $prev = get_previous_snapshot($pdo, $sid, $snap['snapshot_date']);
                        $calc = compute_risk_simple($snap, $prev);
                        $snap['risk_prediction'] = $calc['level'];
                    }

                    insert_snapshot($pdo, $snap);
                    $count++;
                }
                fclose($fh);
                $msg = "Imported $count rows. Errors: $errors";
            }
        } else $msg = $lang['cannot_open'];
    }
}
?>
<!doctype html>
<html>
    <head><meta charset="utf-8">
    <title><?=htmlspecialchars($lang['import_csv_title'])?></title>
<link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="container" style="max-width:700px;margin:28px auto">
  <h2><?=htmlspecialchars($lang['import_csv_title'])?></h2>
  <?php if($msg) echo "<p>".htmlspecialchars($msg)."</p>"; ?>
  <form method="post" enctype="multipart/form-data">
    <input type="file" name="csv_file" accept=".csv" required>
    <button type="submit"><?=htmlspecialchars($lang['import_csv_btn'])?></button>
  </form>

  <p><a href="teacher_dashboard.php"><?=htmlspecialchars($lang['back_dashboard'])?></a></p>

  <!-- Language switcher -->
  <!-- <p>
    <a href="?lang=en">English</a> | 
    <a href="?lang=te">తెలుగు</a> | 
    <a href="?lang=hi">हिन्दी</a>
  </p> -->
</div>
</body>
</html>
