<?php

require_once 'config.php';


function ensure_student(PDO $pdo, string $student_ext_id, string $name, ?string $class=null, ?string $guardian_email=null): int {
    $stmt = $pdo->prepare("SELECT id FROM students WHERE student_id_external = ? LIMIT 1");
    $stmt->execute([$student_ext_id]);
    $r = $stmt->fetch();
    if($r) return (int)$r['id'];

    $ins = $pdo->prepare("INSERT INTO students (student_id_external, full_name, class, guardian_email) VALUES (?,?,?,?)");
    $ins->execute([$student_ext_id, $name, $class, $guardian_email]);
    return (int)$pdo->lastInsertId();
}


// function insert_snapshot(PDO $pdo, array $data): int {
//     $sql = "INSERT INTO student_snapshots
//       (student_id, snapshot_date, total_classes, attended_classes, attendance_pct,
//        test1, test2, test3, avg_score, score_trend,
//        total_fee, paid_fee, pending_fee, fee_due_status, risk_prediction, raw_json)
//       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//     $stmt = $pdo->prepare($sql);
//     $stmt->execute([
//         $data['student_id'],
//         $data['snapshot_date'],
//         $data['total_classes'] ?? null,
//         $data['attended_classes'] ?? null,
//         $data['attendance_pct'] ?? null,
//         $data['test1'] ?? null,
//         $data['test2'] ?? null,
//         $data['test3'] ?? null,
//         $data['avg_score'] ?? null,
//         $data['score_trend'] ?? null,
//         $data['total_fee'] ?? null,
//         $data['paid_fee'] ?? null,
//         $data['pending_fee'] ?? null,
//         $data['fee_due_status'] ?? null,
//         $data['risk_prediction'] ?? null,
//         $data['raw_json'] ?? null
//     ]);
//     return (int)$pdo->lastInsertId();
// }

function insert_snapshot(PDO $pdo, array $data): int {
    $sql = "INSERT INTO student_snapshots 
        (student_id, snapshot_date, total_classes, attended_classes, attendance_pct, 
         test1, test2, test3, avg_score, score_trend, 
         total_fee, paid_fee, pending_fee, fee_due_status, risk_prediction, raw_json) 
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $data['student_id'],
        $data['snapshot_date'],
        $data['total_classes'] ?? null,
        $data['attended_classes'] ?? null,
        $data['attendance_pct'] ?? null,
        $data['test1'] ?? null,
        $data['test2'] ?? null,
        $data['test3'] ?? null,
        $data['avg_score'] ?? null,
        $data['score_trend'] ?? null,
        $data['total_fee'] ?? null,
        $data['paid_fee'] ?? null,
        $data['pending_fee'] ?? null,
        $data['fee_due_status'] ?? null,
        $data['risk_prediction'] ?? null,
        $data['raw_json'] ?? null
    ]);

    $snap_id = (int)$pdo->lastInsertId();

    // 🔥 update latest summary into students table also
    $upd = $pdo->prepare("UPDATE students SET 
        attendance_pct = ?, 
        avg_score = ?, 
        pending_fee = ?, 
        fee_due_status = ?, 
        risk_prediction = ? 
        WHERE id=?");
    $upd->execute([
        $data['attendance_pct'] ?? null,
        $data['avg_score'] ?? null,
        $data['pending_fee'] ?? null,
        $data['fee_due_status'] ?? null,
        $data['risk_prediction'] ?? null,
        $data['student_id']
    ]);

    return $snap_id;
}


function get_latest_snapshots(PDO $pdo): array {
    $sql = "SELECT s.id AS student_id, s.full_name, s.class, s.guardian_email,
            snap.id AS snapshot_id, snap.snapshot_date, snap.total_classes, snap.attended_classes, snap.attendance_pct,
            snap.test1, snap.test2, snap.test3, snap.avg_score, snap.score_trend,
            snap.total_fee, snap.paid_fee, snap.pending_fee, snap.fee_due_status, snap.risk_prediction
        FROM students s
        LEFT JOIN student_snapshots snap ON snap.id = (
            SELECT id FROM student_snapshots ss WHERE ss.student_id = s.id ORDER BY snapshot_date DESC, id DESC LIMIT 1
        )
        ORDER BY s.full_name";
    return $pdo->query($sql)->fetchAll();
}


function get_previous_snapshot(PDO $pdo, int $student_id, string $current_date) {
    $stmt = $pdo->prepare("SELECT * FROM student_snapshots WHERE student_id=? AND snapshot_date < ? ORDER BY snapshot_date DESC, id DESC LIMIT 1");
    $stmt->execute([$student_id, $current_date]);
    return $stmt->fetch();
}


function compute_risk_simple(array $snap, ?array $prev_snap=null): array {
    $points = 0; $reasons = [];

    if (isset($snap['attendance_pct']) && $snap['attendance_pct'] !== null && (float)$snap['attendance_pct'] < 75) {
        $points += 2; $reasons[] = "Low attendance ({$snap['attendance_pct']}%)";
    }
    if (isset($snap['pending_fee']) && (float)$snap['pending_fee'] > 0) {
        $points += 1; $reasons[] = "Pending fee ({$snap['pending_fee']})";
    }
    if ($prev_snap && isset($prev_snap['avg_score']) && isset($snap['avg_score']) && (float)$prev_snap['avg_score'] > 0) {
        $drop = (($prev_snap['avg_score'] - $snap['avg_score'])/max(1,(float)$prev_snap['avg_score']))*100;
        if ($drop >= 15) { $points += 1; $reasons[] = 'Score dropped '.round($drop,1).'%'; }
    }

    $level = ($points >= 4) ? 'HIGH' : (($points >= 2) ? 'MEDIUM' : 'LOW');
    return ['points'=>$points, 'level'=>$level, 'reasons'=>$reasons];
}


function update_snapshot_risk(PDO $pdo, int $snapshot_id, string $risk) {
    $stmt = $pdo->prepare("UPDATE student_snapshots SET risk_prediction=? WHERE id=?");
    $stmt->execute([$risk, $snapshot_id]);
}

function risk_counts(PDO $pdo): array {
    $sql = "SELECT COALESCE(risk_prediction,'UNKNOWN') rp, COUNT(*) c FROM (
        SELECT ss.* FROM student_snapshots ss
        JOIN (
          SELECT student_id, MAX(CONCAT(snapshot_date,'-',id)) mx FROM student_snapshots GROUP BY student_id
        ) t ON t.student_id = ss.student_id AND CONCAT(ss.snapshot_date,'-',ss.id)=t.mx
    ) x GROUP BY rp";
    $rows = $pdo->query($sql)->fetchAll();
    $out = ['LOW'=>0,'MEDIUM'=>0,'HIGH'=>0,'UNKNOWN'=>0];
    foreach($rows as $r) { $out[$r['rp']] = (int)$r['c']; }
    return $out;
}


function send_email(string $to, string $subject, string $html): bool {
    global $MAIL;
    if (!$MAIL['enabled']) return false;

    if (!empty($MAIL['use_phpmailer'])) {
        // Use PHPMailer if installed via Composer
        if (!class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
            // PHPMailer not available
            // fall through to mail()
        } else {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            try {
                // SMTP
                $mail->isSMTP();
                $mail->Host = $MAIL['host'];
                $mail->SMTPAuth = true;
                $mail->Username = $MAIL['username'];
                $mail->Password = $MAIL['password'];
                $mail->SMTPSecure = $MAIL['secure'];
                $mail->Port = $MAIL['port'];

                $mail->setFrom($MAIL['from_email'], $MAIL['from_name'] ?? 'School Alerts');
                $mail->addAddress($to);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $html;
                $mail->send();
                return true;
            } catch (Exception $e) {
                error_log("PHPMailer error: ".$e->getMessage());
                return false;
            }
        }
    }

    // fallback to mail()
    $headers  = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: ".($MAIL['from_name'] ?? 'School Alerts')." <".($MAIL['from_email'] ?? 'no-reply@example.com').">\r\n";
    return @mail($to, $subject, $html, $headers);
}

/* Send SMS via Twilio (cURL) - enable in config */
function send_sms(string $to, string $message): bool {
    global $TWILIO;
    if (empty($TWILIO['enabled'])) return false;
    $sid = $TWILIO['sid'];
    $token = $TWILIO['token'];
    $from = $TWILIO['from'];

    $url = "https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json";
    $data = http_build_query([
        'From' => $from,
        'To' => $to,
        'Body' => $message
    ]);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_USERPWD, $sid.':'.$token);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ($code >= 200 && $code < 300);
}
