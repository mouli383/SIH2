<!-- <?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('parent');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Parent Dashboard</title>
<link rel="stylesheet" href="assets/style.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head><body>
<div class="container">
  <div class="nav">
    <h2 style="margin-right:auto">Parent Dashboard — <?=htmlspecialchars($_SESSION['user_name'])?></h2>
    <a href="index.php">Get Back to Home Page</a>
    <a href="logout.php">Logout</a>
  </div>

  <table class="table" id="kidsTable">
    <tr><th>Name</th><th>Attendance %</th><th>Avg Score</th><th>Pending Fee</th><th>Risk</th></tr>
  </table>

  <div class="grid cols-2" style="margin-top:18px">
    <div><h3>Attendance</h3><canvas id="att"></canvas></div>
    <div><h3>Average Score</h3><canvas id="score"></canvas></div>
  </div>
  <div style="margin-top:18px"><h3>Pending Fee</h3><canvas id="fee"></canvas></div>
</div>

<script>
let c1,c2,c3;
function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function draw(data){
  const names = data.students.map(s=>s.name);
  const att = data.students.map(s=>s.attendance_pct);
  const score = data.students.map(s=>s.avg_score);
  const fee = data.students.map(s=>s.pending_fee);

  const t = document.getElementById('kidsTable');
  t.innerHTML = `<tr><th>Name</th><th>Attendance %</th><th>Avg Score</th><th>Pending Fee</th><th>Risk</th></tr>` +
    data.students.map(s=>`<tr>
      <td>${escapeHtml(s.name)}</td>
      <td>${s.attendance_pct}%</td>
      <td>${s.avg_score}</td>
      <td>${s.pending_fee}</td>
      <td><span class="badge ${escapeHtml(s.risk)}">${escapeHtml(s.risk)}</span></td>
    </tr>`).join('');

  if(!c1){
    c1 = new Chart(document.getElementById('att'), {type:'bar', data:{labels:names, datasets:[{label:'Attendance %', data:att}]}, options:{scales:{y:{beginAtZero:true, max:100}}}});
    c2 = new Chart(document.getElementById('score'), {type:'bar', data:{labels:names, datasets:[{label:'Avg Score', data:score}]}, options:{scales:{y:{beginAtZero:true, max:100}}}});
    c3 = new Chart(document.getElementById('fee'), {type:'bar', data:{labels:names, datasets:[{label:'Pending Fee', data:fee}]}, options:{scales:{y:{beginAtZero:true}}}});
  } else {
    [c1,c2,c3].forEach(c=>c.data.labels = names);
    c1.data.datasets[0].data = att; c1.update();
    c2.data.datasets[0].data = score; c2.update();
    c3.data.datasets[0].data = fee; c3.update();
  }
}

async function refresh(){
  try{
    const r = await fetch('api_parent_overview.php', {cache:'no-store'});
    if(r.ok) draw(await r.json());
  }catch(e){}
}
refresh();
setInterval(refresh, 30000);
</script>
</body></html> -->


<?php
require_once 'config.php';
require_once 'helpers.php';
include "lang_config.php";
require_login_role('parent');
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title><?=$lang['parent_dashboard']?></title>
  <link rel="stylesheet" href="assets/style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="container">
  <div class="nav">
    <h2 style="margin-right:auto"><?=$lang['parent_dashboard']?> — <?=htmlspecialchars($_SESSION['user_name'])?></h2>
    <a href="index.php"><?=$lang['back_home']?></a>
    <a href="logout.php"><?=$lang['logout']?></a>
  </div>

  <table class="table" id="kidsTable">
    <tr>
      <th><?=$lang['name']?></th>
      <th><?=$lang['attendance']?></th>
      <th><?=$lang['avg_score']?></th>
      <th><?=$lang['pending_fee']?></th>
      <th><?=$lang['risk']?></th>
    </tr>
  </table>

  <div class="grid cols-2" style="margin-top:18px">
    <div><h3><?=$lang['attendance']?></h3><canvas id="att"></canvas></div>
    <div><h3><?=$lang['avg_score']?></h3><canvas id="score"></canvas></div>
  </div>
  <div style="margin-top:18px"><h3><?=$lang['pending_fee']?></h3><canvas id="fee"></canvas></div>
</div>

<script>
let c1,c2,c3;
function escapeHtml(s){ 
  return String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); 
}

function draw(data){
  const names = data.students.map(s=>s.name);
  const att = data.students.map(s=>s.attendance_pct);
  const score = data.students.map(s=>s.avg_score);
  const fee = data.students.map(s=>s.pending_fee);

  const t = document.getElementById('kidsTable');
  t.innerHTML = `<tr>
      <th><?=$lang['name']?></th>
      <th><?=$lang['attendance']?></th>
      <th><?=$lang['avg_score']?></th>
      <th><?=$lang['pending_fee']?></th>
      <th><?=$lang['risk']?></th>
    </tr>` +
    data.students.map(s=>`<tr>
      <td>${escapeHtml(s.name)}</td>
      <td>${s.attendance_pct}%</td>
      <td>${s.avg_score}</td>
      <td>${s.pending_fee}</td>
      <td><span class="badge ${escapeHtml(s.risk)}">${escapeHtml(s.risk)}</span></td>
    </tr>`).join('');

  if(!c1){
    c1 = new Chart(document.getElementById('att'), {
      type:'bar', 
      data:{labels:names, datasets:[{label:'<?=$lang['attendance']?>', data:att}]}, 
      options:{scales:{y:{beginAtZero:true, max:100}}}
    });
    c2 = new Chart(document.getElementById('score'), {
      type:'bar', 
      data:{labels:names, datasets:[{label:'<?=$lang['avg_score']?>', data:score}]}, 
      options:{scales:{y:{beginAtZero:true, max:100}}}
    });
    c3 = new Chart(document.getElementById('fee'), {
      type:'bar', 
      data:{labels:names, datasets:[{label:'<?=$lang['pending_fee']?>', data:fee}]}, 
      options:{scales:{y:{beginAtZero:true}}}
    });
  } else {
    [c1,c2,c3].forEach(c=>c.data.labels = names);
    c1.data.datasets[0].data = att; c1.update();
    c2.data.datasets[0].data = score; c2.update();
    c3.data.datasets[0].data = fee; c3.update();
  }
}

async function refresh(){
  try{
    const r = await fetch('api_parent_overview.php', {cache:'no-store'});
    if(r.ok) draw(await r.json());
  }catch(e){}
}
refresh();
setInterval(refresh, 30000);
</script>
</body>
</html>