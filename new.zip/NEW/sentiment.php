<!-- <?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('student'); 

// Default form language
$form_lang = $_GET['form_lang'] ?? 'en';

// Google Form Links (replace with your form IDs)
$forms = [
    "en" => "https://docs.google.com/forms/d/e/1FAIpQLSeHj0o6zJrlJuhsVwJAb0t5sBnsX6_TeZMrZ4GdxlLXSCJ25g/viewform?usp=header",
   
];

$form_url = $forms[$form_lang] ?? $forms['en'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Sentiment Analysis</title>
<link rel="stylesheet" href="assets/style.css">
<style>
:root{
  --bg:#0b1020; --card:#0f1724; --muted:#9fb0c4; --txt:#eaf2f8;
  --ok:#10b981; --warn:#f59e0b; --bad:#ef4444; --link:#60a5fa;
}
*{box-sizing:border-box;}
body{
  margin:0;
  font-family:Inter,system-ui,Segoe UI,Roboto,Arial;
  background:var(--bg);
  color:var(--txt);
}
.center{
  display:grid;
  place-items:center;
  min-height:100vh;
  padding:20px;
}
.card{
  background:var(--card);
  padding:24px;
  border-radius:12px;
  box-shadow:0 10px 30px rgba(0,0,0,.5);
  width:min(800px,96vw);
  text-align:center;
}
.card h2{
  margin-bottom:20px;
}
.button-container {
    display:flex;
    justify-content:center;
    gap:15px;
    margin-bottom:20px;
    flex-wrap:wrap;
}
.button-container a {
    text-decoration:none;
    padding:10px 20px;
    background-color:#2563eb;
    color:var(--txt);
    font-size:16px;
    border-radius:8px;
    box-shadow:0 4px 12px rgba(0,0,0,0.3);
    transition:0.3s;
}
.button-container a:hover{
    background-color:#1e3ca8;
    transform:translateY(-2px);
}
iframe{
    width:100%;
    height:800px;
    border:none;
    border-radius:10px;
    box-shadow:0 4px 12px rgba(0,0,0,.3);
}
</style>
</head>
<body>
<div class="center">
  <div class="card">
    <h2>Sentiment Analysis</h2>
    <div class="button-container">
        <a href="?form_lang=te">తెలుగు</a>
        <a href="?form_lang=en">English</a>
        <a href="?form_lang=hi">हिन्दी</a>
    </div>
    <iframe src="<?= htmlspecialchars($form_url) ?>">Loading…</iframe>
  </div>
</div>

</body>
</html> -->


<?php
require_once 'config.php';
require_login_role('student'); 

// Default form language
$form_lang = $_GET['form_lang'] ?? 'en';

// Google Form Links (replace with your actual form IDs)
$forms = [
    
    "en" => "https://docs.google.com/forms/d/e/1FAIpQLSeHj0o6zJrlJuhsVwJAb0t5sBnsX6_TeZMrZ4GdxlLXSCJ25g/viewform?usp=header",
   
];

$form_url = $forms[$form_lang] ?? $forms['en'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Sentiment Analysis</title>
<link rel="stylesheet" href="assets/style.css">
<style>
:root{
  --bg:#0b1020; --card:#0f1724; --muted:#9fb0c4; --txt:#eaf2f8;
  --ok:#10b981; --warn:#f59e0b; --bad:#ef4444; --link:#60a5fa;
}
*{box-sizing:border-box;}
body{
  margin:0;
  font-family:Inter,system-ui,Segoe UI,Roboto,Arial;
  background:var(--bg);
  color:var(--txt);
}
.center{
  display:grid;
  place-items:center;
  min-height:100vh;
  padding:20px;
}
.card{
  background:var(--card);
  padding:24px;
  border-radius:12px;
  box-shadow:0 10px 30px rgba(0,0,0,.5);
  width:min(800px,96vw);
  text-align:center;
}
.card h2{
  margin-bottom:20px;
}
.button-container {
    display:flex;
    justify-content:center;
    gap:15px;
    margin-bottom:20px;
    flex-wrap:wrap;
}
.button-container a {
    text-decoration:none;
    padding:10px 20px;
    background-color:#2563eb;
    color:var(--txt);
    font-size:16px;
    border-radius:8px;
    box-shadow:0 4px 12px rgba(0,0,0,0.3);
    transition:0.3s;
}
.button-container a:hover{
    background-color:#1e3ca8;
    transform:translateY(-2px);
}
iframe{
    width:100%;
    height:800px;
    border:none;
    border-radius:10px;
    box-shadow:0 4px 12px rgba(0,0,0,0.3);
}
.back-button{
    margin-top:20px;
    text-align:center;
}
.back-button a {
    text-decoration:none;
    padding:12px 25px;
    background-color:#10b981;
    color:#fff;
    font-size:16px;
    border-radius:8px;
    box-shadow:0 4px 12px rgba(0,0,0,0.3);
    transition:0.3s;
}
.back-button a:hover{
    background-color:#0f9d75;
    transform:translateY(-2px);
}
</style>
</head>
<body>
<div class="center">
  <div class="card">
    <h2>Sentiment Analysis</h2>
    <!-- <div class="button-container">
        <a href="?form_lang=te">తెలుగు</a>
        <a href="?form_lang=en">English</a>
        <a href="?form_lang=hi">हिन्दी</a>
    </div> -->

    <iframe src="<?= htmlspecialchars($form_url) ?>">Loading…</iframe>

    <div class="back-button">
        <a href="student_new.php">Back to Dashboard</a>
    </div>
  </div>
</div>
</body>
</html>

