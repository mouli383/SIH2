<?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('mentor');
include "lang_config.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['user_id'])) {
    die($lang['not_logged_in']);
}
$mentor_id = $_SESSION['user_id'];


$sql = "
    SELECT s.id, 
           s.full_name, 
           s.attendance_pct, 
           s.avg_score, 
           s.pending_fee, 
           s.fee_due_status, 
           s.risk_prediction
    FROM students s
    INNER JOIN mentor_students ms 
        ON s.id = ms.student_id
    WHERE ms.mentor_user_id = ?
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$mentor_id]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?=$lang['mentor_dashboard']?></title>
  <link rel="stylesheet" href="assets/style.css">
  <style>
    .badge.low { background: green; color: white; padding: 3px 6px; border-radius: 5px; }
    .badge.medium { background: orange; color: white; padding: 3px 6px; border-radius: 5px; }
    .badge.high { background: red; color: white; padding: 3px 6px; border-radius: 5px; }
  </style>
</head>
<body>
<div class="container">
  <div class="nav">
    <h2 style="margin-right:auto">
      <?=$lang['mentor_dashboard']?> — <?=htmlspecialchars($_SESSION['user_name'])?>
    </h2>
    <!-- <a href="index.php"><?=$lang['home']?></a> -->
      <a href="index.php"><?=$lang['back_home']?></a>
      <a href="mail.html" target="_blank"><?=$lang['send_alerts']?></a>
    <a href="logout.php"><?=$lang['logout']?></a>
  </div>

  <h3><?=$lang['linked_students']?></h3>

  <?php if (empty($students)): ?>
    <p style="color:red"><?=$lang['no_students']?></p>
  <?php else: ?>
    <table class="table">
      <tr>
        <th><?=$lang['name']?></th>
        <th><?=$lang['attendance']?></th>
        <th><?=$lang['avg_score']?></th>
        <th><?=$lang['pending_fee']?></th>
        <th><?=$lang['fee_status']?></th>
        <th><?=$lang['risk']?></th>
      </tr>
      <?php foreach ($students as $s): ?>
      <tr>
        <td><?=htmlspecialchars($s['full_name'])?></td>
        <td><?= $s['attendance_pct'] !== null ? htmlspecialchars($s['attendance_pct']).'%' : '—' ?></td>
        <td><?= $s['avg_score'] !== null ? htmlspecialchars($s['avg_score']) : '—' ?></td>
        <td><?= $s['pending_fee'] !== null ? htmlspecialchars($s['pending_fee']) : '0' ?></td>
        <td><?=htmlspecialchars($s['fee_due_status'] ?? '—')?></td>
        <td>
          <span class="badge <?=strtolower(htmlspecialchars($s['risk_prediction']))?>">
            <?=htmlspecialchars($s['risk_prediction'])?>
          </span>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
</div>
</body>
</html>

