<!-- <?php
require_once 'config.php';
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'student') {
    header('Location: student_login.php');
    exit;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Chat</title>
  <style>
    #chatBox {
      height: 300px;
      overflow-y: auto;
      border: 1px solid #ccc;
      padding: 10px;
      margin-bottom: 10px;
    }
    #msg { width: 80%; }
  </style>
</head>
<body>
  <h2>Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?></h2>
  <div id="chatBox"></div>
  <form id="chatForm">
    <input id="msg" type="text" placeholder="Type a message" required>
    <button type="submit">Send</button>
  </form>

  <script>
  const studentId = <?= (int)$_SESSION['user_id'] ?>;

  async function loadMessages() {
    try {
      const r = await fetch("api/get_messages.php?student_id=" + studentId);
      if (r.ok) {
        const data = await r.json();
        const chatBox = document.getElementById("chatBox");
        chatBox.innerHTML = data.messages.map(m =>
          <div><b>${m.sender_role}:</b> ${m.message}</div>
        ).join("");
        chatBox.scrollTop = chatBox.scrollHeight;
      }
    } catch (e) { console.error(e); }
  }

  document.getElementById("chatForm").onsubmit = async function(e) {
    e.preventDefault();
    const input = document.getElementById("msg");
    const chatBox = document.getElementById("chatBox");

    chatBox.innerHTML += <div><b>You:</b> ${input.value}</div>;
    chatBox.scrollTop = chatBox.scrollHeight;

    await fetch("api/store_message.php", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({
        student_id: studentId,
        sender_role: "student",
        sender_id: studentId,
        message: input.value
      })
    });

    input.value = "";
  };

  setInterval(loadMessages, 3000);
  loadMessages();
  </script>
</body>
</html> -->


<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'student') {
    header('Location: student_login.php');
    exit;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Chat</title>
  <style>
    #chatBox {
      height: 300px;
      overflow-y: auto;
      border: 1px solid #ccc;
      padding: 10px;
      margin-bottom: 10px;
      background: #f9f9f9;
    }
    #msg { width: 80%; }
  </style>
</head>
<body>
  <h2>Welcome, <?= htmlspecialchars($_SESSION['student_name']) ?></h2>
  <div id="chatBox"></div>
  <form id="chatForm">
    <input id="msg" type="text" placeholder="Type a message" required>
    <button type="submit">Send</button>
  </form>

  <script>
  const studentId = <?= (int)$_SESSION['student_id'] ?>;

  async function loadMessages() {
    try {
      const r = await fetch("api/get_messages.php?student_id=" + studentId);
      if (r.ok) {
        const data = await r.json();
        const chatBox = document.getElementById("chatBox");
        chatBox.innerHTML = data.messages.map(m =>
          <div><b>${m.sender_role}:</b> ${m.message}</div>
        ).join("");
        chatBox.scrollTop = chatBox.scrollHeight;
      }
    } catch (e) { console.error(e); }
  }

  document.getElementById("chatForm").onsubmit = async function(e) {
    e.preventDefault();
    const input = document.getElementById("msg");
    const chatBox = document.getElementById("chatBox");

    chatBox.innerHTML += <div><b>You:</b> ${input.value}</div>;
    chatBox.scrollTop = chatBox.scrollHeight;

    await fetch("api/store_message.php", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({
        student_id: studentId,
        sender_role: "student",
        sender_id: studentId,
        message: input.value
      })
    });

    input.value = "";
  };

  setInterval(loadMessages, 3000);
  loadMessages();
  </script>
</body>
</html>