<!-- 


<?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('student'); 

// Get selected language from GET or default to 'en'
$lang_code = $_GET['lang'] ?? 'en';
include "lang/{$lang_code}.php"; // $lang already defined in each file

if (!is_array($lang)) {
    $lang = [
        "student_dashboard" => "Student Dashboard",
        "view_stats" => "View Stats",
        "chat_bot" => "Chat with Chatbot"
    ];
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($lang['student_dashboard'] ?? 'Student Dashboard') ?></title>
<link rel="stylesheet" href="assets/style.css">
<style>
/* === Parent login style base === */
:root{
  --bg:#0b1020; --card:#0f1724; --muted:#9fb0c4; --txt:#eaf2f8;
  --ok:#10b981; --warn:#f59e0b; --bad:#ef4444; --link:#60a5fa;
}
*{box-sizing:border-box;}
body{
  margin:0;
  font-family:Inter,system-ui,Segoe UI,Roboto,Arial;
  background:var(--bg);
  color:var(--txt);
}
.center{
  display:grid;
  place-items:center;
  min-height:100vh;
  padding:20px;
}
.card{
  background:var(--card);
  padding:24px;
  border-radius:12px;
  box-shadow:0 10px 30px rgba(0,0,0,.5);
  width:min(520px,96vw);
  text-align:center;
}
.card h2{
  margin-bottom:25px;
}
.button-container {
    display:flex;
    justify-content:center;
    gap:20px;
    margin-top:25px;
    flex-wrap:wrap;
}
.button-container a {
    text-decoration:none;
    padding:12px 25px;
    background-color:#2563eb;
    color:var(--txt);
    font-size:16px;
    border-radius:10px;
    box-shadow:0 4px 12px rgba(0,0,0,0.3);
    min-width:150px;
    text-align:center;
    transition:0.3s;
}
.button-container a:hover{
    background-color:#1e3ca8;
    transform:translateY(-2px);
}
.language-switcher{
    margin-top:20px;
}
.language-switcher a{
    margin:0 8px;
    text-decoration:none;
    color:var(--link);
}
.language-switcher a:hover{
    text-decoration:underline;
}
</style>
</head>
<body>
<div class="center">
    <div class="card">
        <h2><?= htmlspecialchars($lang['student_dashboard'] ?? 'Student Dashboard') ?></h2>
        <div class="button-container">
            <a href="student_dashboard1.php?lang=<?= urlencode($lang_code) ?>">
                <?= htmlspecialchars($lang['view_stats'] ?? 'View Stats') ?>
            </a>
            <a href="../newbot1/newbot/edubot_final.html?lang=<?= urlencode($lang_code) ?>">
                <?= htmlspecialchars($lang['chat_bot'] ?? 'Chat with Chatbot') ?>
            </a>
        </div>

        <div class="language-switcher">
            <a href="?lang=en">English</a> | 
            <a href="?lang=te">తెలుగు</a> | 
            <a href="?lang=hi">हिन्दी</a>
        </div>
    </div>
</div>
</body>
</html> -->

<!-- <?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('student'); 
// session_start(); // Ensure session

// === 1️⃣ Use session language from index selection ===
$lang_code = $_SESSION['lang'] ?? 'en';
$lang_file = "lang/{$lang_code}.php";
if(file_exists($lang_file)){
    include $lang_file;
} else {
    $lang = [
        "student_dashboard" => "Student Dashboard",
        "view_stats" => "View Stats",
        "chat_bot" => "Chat with Chatbot"
    ];
}

// Optional: handle language switcher clicks
if(isset($_GET['lang'])){
    $new_lang = $_GET['lang'];
    $_SESSION['lang'] = $new_lang;
    header("Location: student_new.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($lang['student_dashboard'] ?? 'Student Dashboard') ?></title>
<link rel="stylesheet" href="assets/style.css">
<style>
:root{
  --bg:#0b1020; --card:#0f1724; --muted:#9fb0c4; --txt:#eaf2f8;
  --ok:#10b981; --warn:#f59e0b; --bad:#ef4444; --link:#60a5fa;
}
*{box-sizing:border-box;}
body{
  margin:0;
  font-family:Inter,system-ui,Segoe UI,Roboto,Arial;
  background:var(--bg);
  color:var(--txt);
}
.center{
  display:grid;
  place-items:center;
  min-height:100vh;
  padding:20px;
}
.card{
  background:var(--card);
  padding:24px;
  border-radius:12px;
  box-shadow:0 10px 30px rgba(0,0,0,.5);
  width:min(520px,96vw);
  text-align:center;
}
.card h2{
  margin-bottom:25px;
}
.button-container {
    display:flex;
    justify-content:center;
    gap:20px;
    margin-top:25px;
    flex-wrap:wrap;
}
.button-container a {
    text-decoration:none;
    padding:12px 25px;
    background-color:#2563eb;
    color:var(--txt);
    font-size:16px;
    border-radius:10px;
    box-shadow:0 4px 12px rgba(0,0,0,0.3);
    min-width:150px;
    text-align:center;
    transition:0.3s;
}
.button-container a:hover{
    background-color:#1e3ca8;
    transform:translateY(-2px);
}
.language-switcher{
    margin-top:20px;
}
.language-switcher a{
    margin:0 8px;
    text-decoration:none;
    color:var(--link);
}
.language-switcher a:hover{
    text-decoration:underline;
}
</style>
</head>
<body>
<div class="center">
    <div class="card">
        <h2><?= htmlspecialchars($lang['student_dashboard'] ?? 'Student Dashboard') ?></h2>
        <div class="button-container">
            <a href="student_dashboard1.php">
                <?= htmlspecialchars($lang['view_stats'] ?? 'Sentiment Analysis') ?>
            </a>
            <a href="student_dashboard1.php">
                <?= htmlspecialchars($lang['view_stats'] ?? 'View Stats') ?>
            </a>
            <a href="../newbot1/newbot/edubot_final.html">
                <?= htmlspecialchars($lang['chat_bot'] ?? 'Chat with Chatbot') ?>
            </a>
        </div>

      
    </div>
</div>
</body>
</html> -->


<?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('student'); 

// session_start(); // Uncomment if not already started
if(session_status() === PHP_SESSION_NONE){
    session_start();
}

// === 1️⃣ Load language from session ===
$lang_code = $_SESSION['lang'] ?? 'en';
$lang_file = "lang/{$lang_code}.php";
if(file_exists($lang_file)){
    include $lang_file;
} else {
    $lang = [
        "student_dashboard" => "Student Dashboard",
        "view_stats" => "View Stats",
        "chat_bot" => "Chat with Chatbot",
        "sentiment_analysis" => "Sentiment Analysis"
    ];
}

// === 2️⃣ Handle language switching ===
if(isset($_GET['lang'])){
    $new_lang = $_GET['lang'];
    $_SESSION['lang'] = $new_lang;
    header("Location: student_new.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?= htmlspecialchars($lang['student_dashboard'] ?? 'Student Dashboard') ?></title>
<link rel="stylesheet" href="assets/style.css">
<style>
:root{
  --bg:#0b1020; --card:#0f1724; --muted:#9fb0c4; --txt:#eaf2f8;
  --ok:#10b981; --warn:#f59e0b; --bad:#ef4444; --link:#60a5fa;
}
*{box-sizing:border-box;}
body{
  margin:0;
  font-family:Inter,system-ui,Segoe UI,Roboto,Arial;
  background:var(--bg);
  color:var(--txt);
}
.center{
  display:grid;
  place-items:center;
  min-height:100vh;
  padding:20px;
}
.card{
  background:var(--card);
  padding:24px;
  border-radius:12px;
  box-shadow:0 10px 30px rgba(0,0,0,.5);
  width:min(520px,96vw);
  text-align:center;
}
.card h2{
  margin-bottom:25px;
}
.button-container {
    display:flex;
    justify-content:center;
    gap:20px;
    margin-top:25px;
    flex-wrap:wrap;
}
.button-container a {
    text-decoration:none;
    padding:12px 25px;
    background-color:#2563eb;
    color:var(--txt);
    font-size:16px;
    border-radius:10px;
    box-shadow:0 4px 12px rgba(0,0,0,0.3);
    min-width:150px;
    text-align:center;
    transition:0.3s;
}
.button-container a:hover{
    background-color:#1e3ca8;
    transform:translateY(-2px);
}
.language-switcher{
    margin-top:20px;
}
.language-switcher a{
    margin:0 8px;
    text-decoration:none;
    color:var(--link);
}
.language-switcher a:hover{
    text-decoration:underline;
}
</style>
</head>
<body>
<div class="center">
    <div class="card">
        <h2><?= htmlspecialchars($lang['student_dashboard'] ?? 'Student Dashboard') ?></h2>
        <div class="button-container">
            <a href="student_dashboard1.php">
                <?= htmlspecialchars($lang['view_stats'] ?? 'View Stats') ?>
            </a>
            <a href="../newbot1/newbot/edubot_final.html">
                <?= htmlspecialchars($lang['chat_bot'] ?? 'Chat with Chatbot') ?>
            </a>
            <a href="sentiment.php">
                <?= htmlspecialchars($lang['sentiment_analysis'] ?? 'Sentiment Analysis') ?>
            </a>
        </div><br><br>
<!-- 
        <div class="language-switcher">
            <a href="?lang=en">English</a> | 
            <a href="?lang=te">తెలుగు</a> | 
            <a href="?lang=hi">हिन्दी</a>
        </div> -->

         <a href="index.php"><?=$lang['back_home']?></a>
    </div>
</div>
</body>
</html>


