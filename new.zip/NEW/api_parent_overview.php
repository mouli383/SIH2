<?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('parent');
header('Content-Type: application/json');
$parent_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT s.* FROM students s JOIN parent_students ps ON ps.student_id=s.id WHERE ps.parent_user_id=?");
$stmt->execute([$parent_id]); $kids = $stmt->fetchAll();
$rows = [];
foreach($kids as $k){
    $q = $pdo->prepare("SELECT * FROM student_snapshots WHERE student_id=? ORDER BY snapshot_date DESC, id DESC LIMIT 1");
    $q->execute([$k['id']]); $snap = $q->fetch();
    $rows[] = [
        'name' => $k['full_name'],
        'attendance_pct' => $snap ? (float)($snap['attendance_pct'] ?? 0) : 0,
        'avg_score' => $snap ? (float)($snap['avg_score'] ?? 0) : 0,
        'pending_fee' => $snap ? (float)($snap['pending_fee'] ?? 0) : 0,
        'risk' => $snap ? ($snap['risk_prediction'] ?? 'UNKNOWN') : 'UNKNOWN'
    ];
}
echo json_encode(['students'=>$rows]);
