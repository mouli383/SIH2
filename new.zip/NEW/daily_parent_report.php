<?php
require_once 'config.php';
require_once 'helpers.php';

// send daily report to every mapped parent
$sql = "SELECT u.email parent_email, s.full_name, ss.attendance_pct, ss.avg_score, ss.pending_fee, ss.risk_prediction
        FROM parent_students ps
        JOIN users u ON u.id=ps.parent_user_id AND u.role='parent'
        JOIN students s ON s.id=ps.student_id
        JOIN (
          SELECT ss1.* FROM student_snapshots ss1
          JOIN (SELECT student_id, MAX(CONCAT(snapshot_date,'-',id)) mx FROM student_snapshots GROUP BY student_id) m
          ON m.student_id=ss1.student_id AND CONCAT(ss1.snapshot_date,'-',ss1.id)=m.mx
        ) ss ON ss.student_id=s.id";
$rows = $pdo->query($sql)->fetchAll();
$sent = 0;
foreach($rows as $r){
    $sub = 'Daily Performance Report — '.$r['full_name'];
    $html = "<p>Hello,</p>
      <p>Today's report for <b>".htmlspecialchars($r['full_name'])."</b>:</p>
      <ul>
        <li>Attendance: ".$r['attendance_pct']."%</li>
        <li>Average Score: ".$r['avg_score']."</li>
        <li>Pending Fee: ₹".$r['pending_fee']."</li>
        <li>Risk: <b>".htmlspecialchars($r['risk_prediction'])."</b></li>
      </ul>
      <p>Regards,<br>School Team</p>";
    if(!empty($r['parent_email'])) {
        if (send_email($r['parent_email'],$sub,$html)) $sent++;
    }
}
echo "Sent $sent daily reports.";
