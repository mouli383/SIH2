

<?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('teacher');

// Fetch latest snapshot for each student with MEDIUM/HIGH risk
$sql = "
SELECT s.id AS student_id, s.full_name, u.email AS parent_email, ss.risk_prediction, ss.attendance_pct, ss.avg_score, ss.pending_fee
FROM students s
JOIN (
    SELECT ss1.*
    FROM student_snapshots ss1
    JOIN (
        SELECT student_id, MAX(CONCAT(snapshot_date,'-',id)) AS mx
        FROM student_snapshots
        GROUP BY student_id
    ) m ON m.student_id = ss1.student_id AND CONCAT(ss1.snapshot_date,'-',ss1.id) = m.mx
) ss ON ss.student_id = s.id
LEFT JOIN parent_students ps ON ps.student_id = s.id
LEFT JOIN users u ON u.id = ps.parent_user_id AND u.role='parent'
WHERE UPPER(ss.risk_prediction) IN ('MEDIUM','HIGH')
";

$rows = $pdo->query($sql)->fetchAll();

if(!$rows) {
    echo "<p>No students found with MEDIUM/HIGH risk.</p>";
    exit;
}

$sent = 0;
$alerted_students = [];

foreach($rows as $r){
    $ok = false;
    $subject = "Counselling Meeting — ".$r['full_name'];
    $when = date('d M Y, h:i A');
    $html = "<p>Dear Parent/Guardian,</p>
      <p>Your child <b>".htmlspecialchars($r['full_name'])."</b> is currently at <b>".htmlspecialchars($r['risk_prediction'])."</b> risk.</p>
      <p>Please attend a counselling meeting scheduled at <b>$when</b> (or contact school).</p>
      <p>Attendance: ".$r['attendance_pct']."% | Avg Score: ".$r['avg_score']." | Pending Fee: ".$r['pending_fee']."</p>
      <p>- School Team</p>";

    // Send email to parent if email exists
    if(!empty($r['parent_email'])) {
        $ok = send_email($r['parent_email'], $subject, $html) || $ok;
    }

    // Optional: send to guardian if email exists
    if(!empty($r['guardian_email'])) {
        $ok = send_email($r['guardian_email'], $subject, $html) || $ok;
    }

    if($ok) {
        $sent++;
        $alerted_students[] = $r['full_name']." (".$r['parent_email'].")";
    }
}

// Display summary
?>
<!DOCTYPE html>
<html>
<head>
    <title>Send Alerts</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        .card { max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; }
        h2 { text-align: center; }
        ul { list-style-type: none; padding: 0; }
        li { margin-bottom: 5px; }
    </style>
</head>
<body>
<div class="card">
    <h2>Alert Summary</h2>
    <p>Alerts successfully sent: <?php echo $sent; ?></p>
    <?php if($alerted_students): ?>
        <h3>Students Alerted:</h3>
        <ul>
            <?php foreach($alerted_students as $s) echo "<li>".htmlspecialchars($s)."</li>"; ?>
        </ul>
    <?php endif; ?>
    <a href="parent_dashboard.php">Back to Dashboard</a>
</div>
</body>
</html>



 <!-- <?php
require_once 'config.php';
require_once 'helpers.php';
require_login_role('mentor');
include "lang_config.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

$mentor_id = $_SESSION['user_id'] ?? null;
if (!$mentor_id) die($lang['not_logged_in']);

// Fetch medium/high risk students for this mentor
$sql = "
    SELECT s.id, s.full_name, s.risk_prediction, s.guardian_email
    FROM students s
    INNER JOIN mentor_students ms ON s.id = ms.student_id
    WHERE ms.mentor_user_id = ?
      AND s.risk_prediction IN ('MEDIUM','HIGH')
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$mentor_id]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

$alerts_sent = [];
if (!empty($students)) {
    foreach ($students as $stu) {
        $parent_email = $stu['guardian_email'];
        if ($parent_email) {
            // Use your existing mailer function here
            // Example: send_mail($parent_email, $subject, $body);
            $subject = "Alert: Student Risk Notification";
            $body = "Dear Parent,\n\nYour child {$stu['full_name']} is at {$stu['risk_prediction']} risk level.\nPlease contact the mentor if needed.\n\nRegards,\nMentor System";

            if(send_mail($parent_email, $subject, $body)){
                $alerts_sent[] = ['student'=>$stu['full_name'], 'parent'=>$parent_email, 'risk'=>$stu['risk_prediction']];
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?=$lang['alerts_summary']?></title>
<link rel="stylesheet" href="assets/style.css">
<style>
table{width:100%;border-collapse:collapse;margin-top:20px}
th,td{border:1px solid #ccc;padding:8px;text-align:left}
.badge.medium{background:orange;color:#fff;padding:3px 6px;border-radius:5px;}
.badge.high{background:red;color:#fff;padding:3px 6px;border-radius:5px;}
</style>
</head>
<body>
<div class="container">
  <h2><?=$lang['alerts_sent']?></h2>
  <?php if(empty($alerts_sent)): ?>
    <p style="color:red"><?=$lang['no_alerts']?></p>
  <?php else: ?>
    <table>
      <tr>
        <th><?=$lang['student_name']?></th>
        <th><?=$lang['parent_email']?></th>
        <th><?=$lang['risk_level']?></th>
      </tr>
      <?php foreach($alerts_sent as $a): ?>
      <tr>
        <td><?=htmlspecialchars($a['student'])?></td>
        <td><?=htmlspecialchars($a['parent'])?></td>
        <td><span class="badge <?=strtolower($a['risk'])?>"><?=htmlspecialchars($a['risk'])?></span></td>
      </tr>
      <?php endforeach; ?>
    </table>
  <?php endif; ?>
  <p><a href="mentor_dashboard.php"><?=$lang['back_dashboard']?></a></p>
</div>
</body>
</html>
 -->


